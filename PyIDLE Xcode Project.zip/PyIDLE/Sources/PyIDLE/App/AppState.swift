import Foundation
import SwiftUI
import Combine
import UniformTypeIdentifiers

public enum IDLELayoutMode: String, CaseIterable, Identifiable {
    case splitHorizontal = "Side by Side"
    case splitVertical = "Stacked"
    case editorOnly = "Editor Only"
    case shellOnly = "Shell Only"
    case turtleSplit = "Canvas Split"
    
    public var id: String { rawValue }
    
    public var icon: String {
        switch self {
        case .splitHorizontal: return "rectangle.split.2x1"
        case .splitVertical: return "rectangle.split.1x2"
        case .editorOnly: return "doc.plaintext"
        case .shellOnly: return "terminal"
        case .turtleSplit: return "paintpalette"
        }
    }
}

@MainActor
public class AppState: ObservableObject {
    @Published public var files: [PythonFile] = [PythonFile.defaultFile()]
    @Published public var activeFileId: UUID
    @Published public var engine = PythonEngine()
    
    // Appearance & Settings
    @Published public var selectedTheme: ThemeType = .idleDark
    @Published public var fontSize: CGFloat = 15.0
    @Published public var fontName: String = "SF Mono"
    @Published public var autoPairBrackets: Bool = true
    @Published public var showRestartBanner: Bool = false
    
    // Layout
    @Published public var layoutMode: IDLELayoutMode = .splitHorizontal
    @Published public var sidebarTab: SidebarTab = .files
    @Published public var isSidebarVisible: Bool = true
    
    // Export / Save As to Files
    @Published public var showFileExporter: Bool = false
    @Published public var fileToExport: PythonDocument = PythonDocument()
    @Published public var exportFileName: String = "script.py"
    
    public init() {
        let initialFile = PythonFile.defaultFile()
        self.files = [initialFile]
        self.activeFileId = initialFile.id
    }
    
    public var activeFile: PythonFile? {
        files.first(where: { $0.id == activeFileId })
    }
    
    public var currentTheme: EditorTheme {
        selectedTheme.theme
    }
    
    // MARK: - File Management
    
    public func createNewFile(name: String = "untitled.py", content: String = "# New Python Script\n\nprint(\"Hello from Python on iPad!\")\n") {
        let newFile = PythonFile(name: name, content: content, isModified: false)
        files.append(newFile)
        activeFileId = newFile.id
    }
    
    public func closeFile(id: UUID) {
        guard files.count > 1 else { return }
        if let idx = files.firstIndex(where: { $0.id == id }) {
            files.remove(at: idx)
            if activeFileId == id {
                activeFileId = files.first?.id ?? UUID()
            }
        }
    }
    
    public func exportFile(_ file: PythonFile) {
        fileToExport = PythonDocument(text: file.content)
        exportFileName = file.displayName
        showFileExporter = true
    }
    
    public func saveFile(_ file: PythonFile) {
        if let idx = files.firstIndex(where: { $0.id == file.id }) {
            if let url = file.fileURL {
                let isAccessing = url.startAccessingSecurityScopedResource()
                defer {
                    if isAccessing {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                do {
                    try file.content.write(to: url, atomically: true, encoding: .utf8)
                    files[idx].markSaved(at: url)
                } catch {
                    print("Failed to save file to \(url):", error)
                    exportFile(file)
                }
            } else {
                // If it doesn't have a disk URL yet, prompt the file exporter
                exportFile(file)
            }
        }
    }
    
    public func openFile(from url: URL) {
        let isAccessing = url.startAccessingSecurityScopedResource()
        defer {
            if isAccessing {
                url.stopAccessingSecurityScopedResource()
            }
        }
        do {
            let content = try String(contentsOf: url, encoding: .utf8)
            let filename = url.lastPathComponent
            
            // If already open, switch to it and sync content
            if let existingIndex = files.firstIndex(where: { $0.fileURL == url || $0.name == filename }) {
                files[existingIndex].updateContent(content)
                files[existingIndex].fileURL = url
                files[existingIndex].markSaved(at: url)
                activeFileId = files[existingIndex].id
            } else {
                var newFile = PythonFile(
                    name: filename,
                    content: content,
                    fileURL: url,
                    isModified: false
                )
                newFile.lastSavedContent = content
                files.append(newFile)
                activeFileId = newFile.id
            }
        } catch {
            print("Failed to open file at \(url):", error)
        }
    }
    
    public func loadExample(_ example: ExampleScript) {
        let name = "\(example.title.replacingOccurrences(of: " ", with: "_").lowercased()).py"
        let newFile = PythonFile(name: name, content: example.code, isModified: false)
        files.append(newFile)
        activeFileId = newFile.id
        
        // If it's a turtle script, switch to turtle split mode
        if example.category.contains("Turtle") || example.category.contains("Visual") {
            layoutMode = .turtleSplit
        }
    }
    
    public func insertSnippet(_ snippet: String) {
        guard let idx = files.firstIndex(where: { $0.id == activeFileId }) else { return }
        var current = files[idx].content
        if !current.hasSuffix("\n") && !current.isEmpty {
            current.append("\n")
        }
        current.append(snippet)
        current.append("\n")
        files[idx].updateContent(current)
    }
    
    // MARK: - Execution
    
    public func runCurrentScript() {
        guard let active = activeFile else { return }
        
        // Auto-switch layout if running turtle code
        if active.content.contains("import turtle") && layoutMode != .turtleSplit {
            layoutMode = .turtleSplit
        }
        
        var filesMap: [String: String] = [:]
        for f in files {
            filesMap[f.name] = f.content
            filesMap[f.displayName] = f.content
        }
        
        engine.runScript(code: active.content, filename: active.displayName, showRestartBanner: showRestartBanner, virtualFiles: filesMap)
    }
}

// MARK: - Cross-Platform View Modifiers
extension View {
    public func disableTextCapitalization() -> some View {
        #if os(iOS)
        return self.textInputAutocapitalization(.never)
        #else
        return self
        #endif
    }
}
