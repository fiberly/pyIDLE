import SwiftUI

#if !TESTING
@main
#endif
public struct PyIDLEApp: App {
    public init() {}
    
    public var body: some Scene {
        WindowGroup {
            MainLayoutView()
        }
    }
}
