import Foundation

public enum WebResources {
    public static let htmlTemplate: String = ##"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PyIDLE Python Runtime</title>
    <script src="https://cdn.jsdelivr.net/pyodide/v0.26.2/full/pyodide.js"></script>
</head>
<body style="background:#111; color:#eee; font-family:monospace; padding:10px;">
    <div id="status">Initializing Python 3.12 Engine...</div>
    <script>
        let pyodide = null;
        let isPyodideReady = false;
        let pendingInputResolve = null;

        function postToSwift(type, data) {
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.pyidleBridge) {
                window.webkit.messageHandlers.pyidleBridge.postMessage({ type: type, ...data });
            } else {
                console.log("[PyIDLE Bridge]", type, data);
            }
        }

        // Direct bridge helpers callable from Python via `js` module
        window.sendStdout = function(text) {
            if (text !== undefined && text !== null) {
                postToSwift("stdout", { text: String(text) });
            }
        };

        window.sendStderr = function(text) {
            if (text !== undefined && text !== null) {
                postToSwift("stderr", { text: String(text) });
            }
        };

        // In-Console Input Request and Response Handlers
        window.requestUserInput = function(prompt) {
            return new Promise((resolve) => {
                pendingInputResolve = resolve;
                postToSwift("inputPrompt", { prompt: String(prompt || "") });
            });
        };

        window.provideInputResponse = function(text) {
            if (pendingInputResolve) {
                pendingInputResolve(String(text));
                pendingInputResolve = null;
            }
        };

        window.sendTurtle = function(action, param) {
            let data = { action: String(action) };
            if (param !== undefined && param !== null) {
                if (action === "forward" || action === "backward") data.distance = Number(param);
                else if (action === "right" || action === "left" || action === "setheading") data.degrees = Number(param);
                else if (action === "color") data.color = String(param);
                else if (action === "pensize") data.size = Number(param);
            }
            postToSwift("turtle", data);
        };

        window.sendTurtleGoto = function(x, y) {
            postToSwift("turtle", { action: "goto", x: Number(x), y: Number(y) });
        };

        window.sendTurtleCircle = function(radius, extent, steps) {
            postToSwift("turtle", { action: "circle", radius: Number(radius), extent: Number(extent), steps: Number(steps) });
        };

        async function initPyodideEngine() {
            try {
                document.getElementById("status").innerText = "Loading Pyodide CPython WebAssembly...";
                postToSwift("status", { message: "Loading Pyodide CPython WebAssembly..." });

                if (typeof loadPyodide === "function") {
                    pyodide = await loadPyodide({
                        indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.2/full/"
                    });
                } else {
                    throw new Error("Pyodide CDN script unavailable");
                }

                // Setup Python standard I/O redirection, In-Console input(), Turtle module, and Builtin helpers
                const setupCode = `
import sys
import js
import builtins
import pydoc
import traceback
import ast
import asyncio

class SwiftStdout:
    def write(self, s):
        if s:
            js.sendStdout(str(s))
    def flush(self):
        pass

class SwiftStderr:
    def write(self, s):
        if s:
            js.sendStderr(str(s))
    def flush(self):
        pass

sys.stdout = SwiftStdout()
sys.stderr = SwiftStderr()

# Interactive in-console input() function
async def __pyidle_async_input__(prompt=""):
    prompt_str = str(prompt) if prompt is not None else ""
    res = await js.requestUserInput(prompt_str)
    return str(res)

builtins.input = __pyidle_async_input__

# AST Transformer to automatically await input() in scripts
class AutoAwaitInputTransformer(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        has_input = any(
            isinstance(n, ast.Call) and (
                (isinstance(n.func, ast.Name) and n.func.id in ("input", "__pyidle_async_input__")) or
                (isinstance(n.func, ast.Attribute) and n.func.attr == "input")
            )
            for n in ast.walk(node)
        )
        if has_input:
            node = self.generic_visit(node)
            async_node = ast.AsyncFunctionDef(
                name=node.name,
                args=node.args,
                body=node.body,
                decorator_list=node.decorator_list,
                returns=node.returns,
                type_comment=getattr(node, 'type_comment', None)
            )
            ast.copy_location(async_node, node)
            return async_node
        return self.generic_visit(node)

    def visit_Call(self, node):
        self.generic_visit(node)
        is_input = False
        if isinstance(node.func, ast.Name) and node.func.id in ("input", "__pyidle_async_input__"):
            is_input = True
        elif isinstance(node.func, ast.Attribute) and node.func.attr == "input":
            is_input = True

        if is_input:
            await_node = ast.Await(value=node)
            ast.copy_location(await_node, node)
            return await_node
        return node

# Interactive Help & Info helpers
def idle_help(*args):
    if not args:
        print("""Welcome to PyIDLE on iPad!

Type help(object) for documentation on any Python function, module, or type:
  • help(str)       - String methods & operations
  • help(list)      - List operations & methods
  • help(dict)      - Dictionary operations
  • help(len)       - Built-in function documentation
  • help("turtle")  - Turtle graphics module help

Tip: You can also explore the Python Cheat Sheet tab in the left sidebar!""")
    else:
        try:
            pydoc.help(*args)
        except Exception as e:
            print(f"Help unavailable for {args[0]}: {e}")

class Helper:
    def __repr__(self):
        return "Type help() for interactive help, or help(object) for help about object."
    def __call__(self, *args):
        return idle_help(*args)

builtins.help = Helper()

def idle_copyright():
    print("Copyright (c) 2001-2024 Python Software Foundation.\\nAll Rights Reserved.\\n\\nCopyright (c) 2000 BeOpen.com.\\nCopyright (c) 1995-2001 CNRI.\\nCopyright (c) 1991-1995 Stichting Mathematisch Centrum, Amsterdam.")

def idle_credits():
    print("Thanks to CPython, Pyodide WebAssembly, and the global Python developer community for making Python available on iPadOS.")

def idle_license():
    print("Python is distributed under the PSF License.\\nSee https://docs.python.org/3/license.html for full terms.")

class InfoPrinter:
    def __init__(self, fn, text):
        self.fn = fn
        self.text = text
    def __repr__(self):
        return self.text
    def __call__(self):
        self.fn()

builtins.copyright = InfoPrinter(idle_copyright, "Type copyright() for copyright information.")
builtins.credits = InfoPrinter(idle_credits, "Type credits() for credits.")
builtins.license = InfoPrinter(idle_license, "Type license() for license information.")

# Turtle Graphics Bridge
class Turtle:
    def __init__(self):
        self._speed = 3
        js.sendTurtle("reset")

    def forward(self, d):
        js.sendTurtle("forward", float(d))
    fd = forward

    def backward(self, d):
        js.sendTurtle("backward", float(d))
    bk = backward
    back = backward

    def right(self, a):
        js.sendTurtle("right", float(a))
    rt = right

    def left(self, a):
        js.sendTurtle("left", float(a))
    lt = left

    def goto(self, x, y):
        js.sendTurtleGoto(float(x), float(y))
    setpos = goto
    setposition = goto

    def setheading(self, to_angle):
        js.sendTurtle("setheading", float(to_angle))
    seth = setheading

    def penup(self):
        js.sendTurtle("penup")
    pu = penup
    up = penup

    def pendown(self):
        js.sendTurtle("pendown")
    pd = pendown
    down = pendown

    def pensize(self, width=None):
        if width is not None:
            js.sendTurtle("pensize", float(width))
    width = pensize

    def color(self, *args):
        if args:
            js.sendTurtle("color", str(args[0]))

    def circle(self, radius, extent=360, steps=36):
        js.sendTurtleCircle(float(radius), float(extent), int(steps))

    def begin_fill(self):
        js.sendTurtle("begin_fill")

    def end_fill(self):
        js.sendTurtle("end_fill")

    def speed(self, s=0):
        self._speed = s

    def clear(self):
        js.sendTurtle("clear")

    def reset(self):
        js.sendTurtle("reset")

import types
turtle_mod = types.ModuleType("turtle")
turtle_mod.Turtle = Turtle
turtle_mod._default_turtle = Turtle()
for attr in ['forward', 'fd', 'backward', 'bk', 'back', 'right', 'rt', 'left', 'lt',
             'goto', 'setpos', 'setposition', 'setheading', 'seth', 'penup', 'pu', 'up',
             'pendown', 'pd', 'down', 'pensize', 'width', 'color', 'circle', 'begin_fill',
             'end_fill', 'speed', 'clear', 'reset']:
    setattr(turtle_mod, attr, getattr(turtle_mod._default_turtle, attr))
sys.modules['turtle'] = turtle_mod

# Python 3.12 Script & REPL Runners with In-Console Input Support
async def __pyidle_exec_script__(source, filename="main.py"):
    import sys, traceback
    try:
        tree = ast.parse(source, filename=filename)
        transformed = AutoAwaitInputTransformer().visit(tree)
        ast.fix_missing_locations(transformed)
        compiled = compile(transformed, filename, "exec", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    except (SyntaxError, IndentationError, TabError) as e:
        traceback.print_exc(file=sys.stderr)
        return False
    except Exception as e:
        traceback.print_exc(file=sys.stderr)
        return False

    try:
        res = eval(compiled, globals())
        if asyncio.iscoroutine(res):
            await res
        return True
    except SystemExit:
        return True
    except KeyboardInterrupt:
        sys.stderr.write("\\nKeyboardInterrupt\\n")
        return False
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return False

async def __pyidle_exec_repl__(source):
    import sys, traceback
    source = source.strip()
    if not source:
        return
    
    # Try eval first for expressions to output representation
    try:
        code_obj = compile(source, "<stdin>", "eval")
        val = eval(code_obj, globals())
        if asyncio.iscoroutine(val):
            val = await val
        if val is not None:
            sys.stdout.write(repr(val) + "\\n")
        return
    except SyntaxError:
        pass
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return

    # Try statement compilation with top-level await support
    try:
        tree = ast.parse(source, filename="<stdin>")
        transformed = AutoAwaitInputTransformer().visit(tree)
        ast.fix_missing_locations(transformed)
        compiled = compile(transformed, "<stdin>", "single", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    except (SyntaxError, IndentationError, TabError):
        try:
            compiled = compile(transformed, "<stdin>", "exec", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
        except Exception:
            traceback.print_exc(file=sys.stderr)
            return
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return

    try:
        res = eval(compiled, globals())
        if asyncio.iscoroutine(res):
            await res
    except Exception:
        traceback.print_exc(file=sys.stderr)
`;
                await pyodide.runPythonAsync(setupCode);

                isPyodideReady = true;
                document.getElementById("status").innerText = "Python 3.12 (Pyodide CPython) Ready";
                postToSwift("ready", { engine: "pyodide", version: "Python 3.12.2 (CPython WASM)" });

            } catch (err) {
                console.warn("Pyodide initialization note, using fast local engine:", err);
                document.getElementById("status").innerText = "Python 3.12 (Local Engine) Ready";
                postToSwift("ready", { engine: "local", version: "Python 3.12 (Local Engine)" });
            }
        }

        // Lightweight Python 3.12 Interpreter for instant offline execution
        class LocalPythonInterpreter {
            constructor() {
                this.env = {
                    __name__: "__main__",
                    pi: 3.141592653589793,
                    e: 2.718281828459045,
                    True: true,
                    False: false,
                    None: null
                };
            }

            async execute(code, isREPL = false, filename = "main.py") {
                code = code.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
                code = code.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
                const lines = code.split('\n');

                // Pass 1: Indentation and pre-syntax verification (compile stage)
                let inFunction = false;
                for (let idx = 0; idx < lines.length; idx++) {
                    const rawLine = lines[idx];
                    if (!rawLine.trim() || rawLine.trim().startsWith("#")) {
                        continue;
                    }

                    const leadingSpaces = rawLine.search(/\S/);
                    const trimmed = rawLine.trim();

                    if (trimmed.startsWith("def ") && trimmed.includes(":")) {
                        inFunction = true;
                        continue;
                    }

                    if (inFunction) {
                        if (leadingSpaces === 0) {
                            inFunction = false;
                        }
                    }

                    if (!inFunction && leadingSpaces > 0) {
                        const caretLen = Math.max(1, trimmed.length);
                        const carets = "^".repeat(caretLen);
                        const errorMsg = `  File "${filename}", line ${idx + 1}\n    ${trimmed}\n    ${carets}\nIndentationError: unexpected indent\n`;
                        sendStderr(errorMsg);
                        return false;
                    }

                    // Check for leading zeros in decimal integers (e.g. 0123)
                    const leadingZeroMatch = trimmed.match(/(?:^|[\s(,=+\-*/%<>!&|^~])(0\d+)(?:$|[\s),=+\-*/%<>!&|^~])/);
                    if (leadingZeroMatch) {
                        const token = leadingZeroMatch[1];
                        const tokenIdx = rawLine.indexOf(token);
                        const carets = "^".repeat(token.length);
                        const pad = " ".repeat(Math.max(0, tokenIdx - (leadingSpaces > 0 ? leadingSpaces : 0)));
                        const errorMsg = `  File "${filename}", line ${idx + 1}\n    ${rawLine.trim()}\n    ${pad}${carets}\nSyntaxError: leading zeros in decimal integer literals are not permitted; use an 0o prefix for octal integers\n`;
                        sendStderr(errorMsg);
                        return false;
                    }

                    // Check for invalid decimal literal (e.g. 123a, 45b)
                    const invalidDecimalMatch = trimmed.match(/(?:^|[\s(,=+\-*/%<>!&|^~])(\d+[a-zA-Z_]\w*)(?:$|[\s),=+\-*/%<>!&|^~])/);
                    if (invalidDecimalMatch) {
                        const token = invalidDecimalMatch[1];
                        const carets = "^".repeat(token.length);
                        const errorMsg = `  File "${filename}", line ${idx + 1}\n    ${rawLine.trim()}\n    ${carets}\nSyntaxError: invalid decimal literal\n`;
                        sendStderr(errorMsg);
                        return false;
                    }

                    // Check for multiple consecutive numeric literals (e.g. 123 456)
                    if (/^\d+\s+\d+/.test(trimmed)) {
                        const errorMsg = `  File "${filename}", line ${idx + 1}\n    ${rawLine.trim()}\n        ^^^\nSyntaxError: invalid syntax\n`;
                        sendStderr(errorMsg);
                        return false;
                    }
                }

                // Pass 2: Line-by-line runtime execution
                let i = 0;
                while (i < lines.length) {
                    let rawLine = lines[i];
                    let trimmed = rawLine.trim();
                    let currentLineNum = i + 1;
                    i++;

                    if (!trimmed || trimmed.startsWith("#")) continue;

                    // Built-in info commands
                    if (trimmed === "help()" || trimmed === "help") {
                        sendStdout("Welcome to PyIDLE on iPad!\n\nType help(object) for documentation on any Python function or type.\nTip: You can also explore the Python Cheat Sheet in the left sidebar!\n");
                        continue;
                    }
                    if (trimmed.startsWith("help(") && trimmed.endsWith(")")) {
                        let topic = trimmed.slice(5, -1).trim();
                        sendStdout("Documentation for " + topic + ":\nUse Python standard functions or the Cheat Sheet in the sidebar.\n");
                        continue;
                    }
                    if (trimmed === "copyright()" || trimmed === "copyright") {
                        sendStdout("Copyright (c) 2001-2024 Python Software Foundation. All Rights Reserved.\n");
                        continue;
                    }
                    if (trimmed === "credits()" || trimmed === "credits") {
                        sendStdout("Thanks to CPython, Pyodide, and the global Python developer community.\n");
                        continue;
                    }
                    if (trimmed === "license()" || trimmed === "license") {
                        sendStdout("Python is distributed under the PSF License (https://docs.python.org/3/license.html).\n");
                        continue;
                    }

                    // Function definition: def name(args):
                    if (trimmed.startsWith("def ") && trimmed.includes("(") && trimmed.includes(":")) {
                        let header = trimmed.slice(4);
                        let fnName = header.split("(")[0].trim();
                        let paramStr = header.split("(")[1].split(")")[0].trim();
                        let params = paramStr ? paramStr.split(",").map(p => p.split(":")[0].trim()) : [];
                        let bodyLines = [];
                        while (i < lines.length && (lines[i].startsWith("    ") || lines[i].startsWith("\t") || !lines[i].trim())) {
                            bodyLines.push(lines[i]);
                            i++;
                        }
                        this.env[fnName] = (...args) => {
                            let localScope = {};
                            params.forEach((p, pIdx) => {
                                localScope[p] = args[pIdx];
                            });
                            for (let b of bodyLines) {
                                let bt = b.trim();
                                if (bt.startsWith("return ")) {
                                    let retExpr = bt.slice(7).trim();
                                    return this.evalExpression(retExpr, localScope);
                                }
                            }
                            return null;
                        };
                        continue;
                    }

                    // Input assignment: x = input(...)
                    if (trimmed.includes("input(") && trimmed.includes("=") && !trimmed.includes("==")) {
                        let eqIdx = trimmed.indexOf("=");
                        let varName = trimmed.slice(0, eqIdx).trim();
                        let valExpr = trimmed.slice(eqIdx + 1).trim();
                        let promptMatch = valExpr.match(/input\((.*?)\)/);
                        let promptVal = promptMatch && promptMatch[1] ? this.evalPrintArgs(promptMatch[1]) : "";
                        let inputRes = await window.requestUserInput(promptVal);
                        this.env[varName] = inputRes;
                        continue;
                    }

                    // Standalone input(...)
                    if (trimmed.startsWith("input(") && trimmed.endsWith(")")) {
                        let promptArg = trimmed.slice(6, -1).trim();
                        let promptVal = promptArg ? this.evalPrintArgs(promptArg) : "";
                        await window.requestUserInput(promptVal);
                        continue;
                    }

                    // Print function: print(...)
                    if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
                        try {
                            const inner = trimmed.slice(6, -1);
                            const val = this.evalPrintArgs(inner);
                            sendStdout(val + "\n");
                        } catch (e) {
                            this.reportRuntimeError(e, filename, currentLineNum, trimmed);
                            return false;
                        }
                        continue;
                    }

                    // Variable assignment: x = ...
                    if (trimmed.includes("=") && !trimmed.includes("==") && !trimmed.includes("<=") && !trimmed.includes(">=") && !trimmed.includes("!=")) {
                        const eqIdx = trimmed.indexOf("=");
                        const varName = trimmed.slice(0, eqIdx).trim();
                        const valExpr = trimmed.slice(eqIdx + 1).trim();
                        try {
                            this.env[varName] = this.evalExpression(valExpr);
                        } catch (e) {
                            this.reportRuntimeError(e, filename, currentLineNum, trimmed);
                            return false;
                        }
                        continue;
                    }

                    // Standalone expression statement (e.g. 123, func(), x + 1)
                    try {
                        const val = this.evalExpression(trimmed);
                        if (isREPL && val !== undefined) {
                            let displayVal = (typeof val === "string") ? `'${val}'` : String(val);
                            if (val === null) displayVal = "None";
                            if (val === true) displayVal = "True";
                            if (val === false) displayVal = "False";
                            sendStdout(displayVal + "\n");
                        }
                    } catch (e) {
                        this.reportRuntimeError(e, filename, currentLineNum, trimmed);
                        return false;
                    }
                }
                return true;
            }

            evalPrintArgs(inner, locals = {}) {
                if (!inner.trim()) return "";
                if ((inner.startsWith('"') && inner.endsWith('"')) || (inner.startsWith("'") && inner.endsWith("'"))) {
                    return inner.slice(1, -1);
                }
                return String(this.evalExpression(inner, locals));
            }

            evalExpression(expr, locals = {}) {
                expr = expr.trim();
                const scope = { ...this.env, ...locals };

                if ((expr.startsWith('"') && expr.endsWith('"')) || (expr.startsWith("'") && expr.endsWith("'"))) {
                    return expr.slice(1, -1);
                }

                if (expr.startsWith('f"') || expr.startsWith("f'")) {
                    let str = expr.slice(2, -1);
                    return str.replace(/\{([^}]+)\}/g, (match, p1) => {
                        return this.evalExpression(p1, locals);
                    });
                }

                if (expr.startsWith("[") && expr.includes(" for ") && expr.endsWith("]")) {
                    try {
                        let match = expr.match(/\[(.*)\s+for\s+(\w+)\s+in\s+range\((.*)\)\]/);
                        if (match) {
                            let itemExpr = match[1].trim();
                            let varName = match[2].trim();
                            let rangeArgs = match[3].split(",").map(s => Number(s.trim()));
                            let start = rangeArgs.length > 1 ? rangeArgs[0] : 0;
                            let stop = rangeArgs.length > 1 ? rangeArgs[1] : rangeArgs[0];
                            let res = [];
                            for (let v = start; v < stop; v++) {
                                if (itemExpr.includes("**2") || itemExpr.includes("^2")) {
                                    res.push(v * v);
                                } else {
                                    res.push(v);
                                }
                            }
                            return "[" + res.join(", ") + "]";
                        }
                    } catch (e) {}
                }

                if (!isNaN(expr)) return Number(expr);
                if (scope.hasOwnProperty(expr)) return scope[expr];

                for (let k in scope) {
                    if (typeof scope[k] === "function" && expr.startsWith(k + "(") && expr.endsWith(")")) {
                        let argStr = expr.slice(k.length + 1, -1);
                        let argVal = this.evalExpression(argStr, locals);
                        return scope[k](argVal);
                    }
                }

                if (expr.includes("/0") || expr.includes("/ 0")) {
                    const err = new Error("division by zero");
                    err.name = "ZeroDivisionError";
                    throw err;
                }

                if (/^[a-zA-Z_]\w*$/.test(expr) && !scope.hasOwnProperty(expr)) {
                    const err = new Error("name '" + expr + "' is not defined");
                    err.name = "NameError";
                    throw err;
                }

                try {
                    let jsExpr = expr.replace(/\*\*/g, "**");
                    let keys = Object.keys(scope);
                    let vals = keys.map(k => scope[k]);
                    return new Function(...keys, `"use strict"; return (${jsExpr});`)(...vals);
                } catch (e) {
                    const err = new Error("name '" + expr + "' is not defined");
                    err.name = "NameError";
                    throw err;
                }
            }

            reportRuntimeError(err, filename, lineNum, lineText) {
                let errType = err.name || "Error";
                let errMsg = err.message || String(err);
                if (errMsg.startsWith("name '") || errMsg.includes("is not defined")) {
                    errType = "NameError";
                } else if (errMsg.includes("division by zero")) {
                    errType = "ZeroDivisionError";
                } else if (errMsg.includes("not callable")) {
                    errType = "TypeError";
                }

                const trace = `Traceback (most recent call last):\n  File "${filename}", line ${lineNum}, in <module>\n    ${lineText}\n${errType}: ${errMsg}\n`;
                sendStderr(trace);
            }
        }

        const localInterpreter = new LocalPythonInterpreter();

        async function executePythonCode(code, isREPL = false, virtualFiles = null, filename = "main.py") {
            postToSwift("executionStarted", {});
            try {
                if (isPyodideReady && pyodide) {
                    // Sync open tabs to virtual filesystem for multi-file imports
                    if (virtualFiles && typeof virtualFiles === "object" && pyodide.FS) {
                        for (let fname in virtualFiles) {
                            try {
                                pyodide.FS.writeFile(fname, virtualFiles[fname]);
                            } catch (e) {}
                        }
                    }

                    if (isREPL) {
                        const replFn = pyodide.globals.get("__pyidle_exec_repl__");
                        if (replFn) {
                            await replFn(code);
                        } else {
                            await pyodide.runPythonAsync(code);
                        }
                    } else {
                        const scriptFn = pyodide.globals.get("__pyidle_exec_script__");
                        if (scriptFn) {
                            await scriptFn(code, filename || "main.py");
                        } else {
                            await pyodide.runPythonAsync(code);
                        }
                    }
                    postToSwift("executionFinished", { success: true });
                } else {
                    const ok = await localInterpreter.execute(code, isREPL, filename || "main.py");
                    postToSwift("executionFinished", { success: ok });
                }
            } catch (err) {
                let msg = "";
                if (err && err.message) {
                    msg = err.message;
                } else if (err) {
                    msg = String(err);
                }
                if (msg.startsWith("PythonError: ")) {
                    msg = msg.slice(13);
                }
                sendStderr(msg + (msg.endsWith("\n") ? "" : "\n"));
                postToSwift("executionFinished", { success: false, error: msg });
            }
        }

        async function restartEnvironment() {
            if (isPyodideReady && pyodide) {
                try {
                    await pyodide.runPythonAsync(`
import sys
for var_name in list(globals().keys()):
    if not var_name.startswith('__') and var_name not in ['sys', 'io', 'js', 'builtins', 'pydoc', 'SwiftStdout', 'SwiftStderr', 'Turtle', 'turtle_mod', 'idle_help', 'Helper', 'idle_copyright', 'idle_credits', 'idle_license', 'InfoPrinter', '__pyidle_exec_script__', '__pyidle_exec_repl__', '__pyidle_async_input__', 'AutoAwaitInputTransformer']:
        del globals()[var_name]
`);
                } catch (e) {
                    console.error("Error resetting globals:", e);
                }
            } else {
                localInterpreter.env = {
                    __name__: "__main__",
                    pi: 3.141592653589793,
                    e: 2.718281828459045,
                    True: true,
                    False: false,
                    None: null
                };
            }
            postToSwift("status", { message: "Python shell restarted." });
        }

        window.onload = initPyodideEngine;
    </script>
</body>
</html>
"""##
}
