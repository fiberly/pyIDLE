import SwiftUI
import WebKit

#if os(iOS)
import UIKit

public struct PyodideBridgeView: UIViewRepresentable {
    @ObservedObject var engine: PythonEngine
    
    public init(engine: PythonEngine) {
        self.engine = engine
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(engine: engine)
    }
    
    public func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let contentController = WKUserContentController()
        contentController.add(context.coordinator, name: "pyidleBridge")
        config.userContentController = contentController
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
        
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 10, height: 10), configuration: config)
        webView.navigationDelegate = context.coordinator
        context.coordinator.webView = webView
        
        engine.executeJSScript = { [weak webView] js in
            DispatchQueue.main.async {
                webView?.evaluateJavaScript(js) { _, error in
                    if let error = error {
                        print("[PyIDLE Bridge Error]", error)
                    }
                }
            }
        }
        
        webView.loadHTMLString(WebResources.htmlTemplate, baseURL: URL(string: "https://cdn.jsdelivr.net/pyodide/v0.26.2/full/"))
        return webView
    }
    
    public func updateUIView(_ uiView: WKWebView, context: Context) {
        context.coordinator.engine = engine
    }
    
    public class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        var engine: PythonEngine
        weak var webView: WKWebView?
        
        init(engine: PythonEngine) {
            self.engine = engine
        }
        
        public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "pyidleBridge", let body = message.body as? [String: Any] {
                DispatchQueue.main.async {
                    self.engine.handleBridgeMessage(body)
                }
            }
        }
        
        public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            print("[PyIDLE WebView Navigation Error]", error)
        }
        
        public func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            print("[PyIDLE WebView Provisional Navigation Error]", error)
        }
    }
}
#elseif os(macOS)
import AppKit

public struct PyodideBridgeView: NSViewRepresentable {
    @ObservedObject var engine: PythonEngine
    
    public init(engine: PythonEngine) {
        self.engine = engine
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(engine: engine)
    }
    
    public func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let contentController = WKUserContentController()
        contentController.add(context.coordinator, name: "pyidleBridge")
        config.userContentController = contentController
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
        
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: 10, height: 10), configuration: config)
        context.coordinator.webView = webView
        
        engine.executeJSScript = { [weak webView] js in
            DispatchQueue.main.async {
                webView?.evaluateJavaScript(js) { _, error in
                    if let error = error {
                        print("[PyIDLE Bridge Error]", error)
                    }
                }
            }
        }
        
        webView.loadHTMLString(WebResources.htmlTemplate, baseURL: URL(string: "https://cdn.jsdelivr.net/pyodide/v0.26.2/full/"))
        return webView
    }
    
    public func updateNSView(_ nsView: WKWebView, context: Context) {
        context.coordinator.engine = engine
    }
    
    public class Coordinator: NSObject, WKScriptMessageHandler {
        var engine: PythonEngine
        weak var webView: WKWebView?
        
        init(engine: PythonEngine) {
            self.engine = engine
        }
        
        public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "pyidleBridge", let body = message.body as? [String: Any] {
                DispatchQueue.main.async {
                    self.engine.handleBridgeMessage(body)
                }
            }
        }
    }
}
#endif
