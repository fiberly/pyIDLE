import SwiftUI
import Combine

public struct TurtleLineSegment: Identifiable {
    public let id = UUID()
    public let start: CGPoint
    public let end: CGPoint
    public let color: Color
    public let width: CGFloat
}

public struct TurtlePolygon: Identifiable {
    public let id = UUID()
    public let points: [CGPoint]
    public let fillColor: Color
}

@MainActor
public class TurtleState: ObservableObject {
    @Published public var segments: [TurtleLineSegment] = []
    @Published public var polygons: [TurtlePolygon] = []
    @Published public var currentPosition: CGPoint = .zero
    @Published public var currentAngle: Double = 90.0 // 90 is facing East in standard turtle (0 is East in math, IDLE turtle starts facing East)
    @Published public var isPenDown: Bool = true
    @Published public var currentColor: Color = .black
    @Published public var currentPenWidth: CGFloat = 2.0
    @Published public var isVisible: Bool = true
    @Published public var backgroundColor: Color = .white
    
    // Fill tracking
    private var isFilling: Bool = false
    private var currentFillPoints: [CGPoint] = []
    private var currentFillColor: Color = .black
    
    public init() {
        reset()
    }
    
    public func reset() {
        segments.removeAll()
        polygons.removeAll()
        currentPosition = .zero
        currentAngle = 0.0 // 0 = East
        isPenDown = true
        currentColor = .black
        currentPenWidth = 2.0
        isVisible = true
        backgroundColor = .white
        isFilling = false
        currentFillPoints.removeAll()
    }
    
    public func clear() {
        segments.removeAll()
        polygons.removeAll()
    }
    
    public func forward(distance: Double) {
        let radians = currentAngle * .pi / 180.0
        let dx = distance * cos(radians)
        let dy = -distance * sin(radians) // Invert Y for screen coordinates (up is positive in turtle)
        let newPos = CGPoint(x: currentPosition.x + dx, y: currentPosition.y + dy)
        
        if isPenDown {
            segments.append(TurtleLineSegment(
                start: currentPosition,
                end: newPos,
                color: currentColor,
                width: currentPenWidth
            ))
        }
        
        if isFilling {
            currentFillPoints.append(newPos)
        }
        
        currentPosition = newPos
    }
    
    public func backward(distance: Double) {
        forward(distance: -distance)
    }
    
    public func right(degrees: Double) {
        currentAngle = (currentAngle - degrees).truncatingRemainder(dividingBy: 360.0)
    }
    
    public func left(degrees: Double) {
        currentAngle = (currentAngle + degrees).truncatingRemainder(dividingBy: 360.0)
    }
    
    public func goto(x: Double, y: Double) {
        let newPos = CGPoint(x: x, y: -y)
        if isPenDown {
            segments.append(TurtleLineSegment(
                start: currentPosition,
                end: newPos,
                color: currentColor,
                width: currentPenWidth
            ))
        }
        if isFilling {
            currentFillPoints.append(newPos)
        }
        currentPosition = newPos
    }
    
    public func setHeading(angle: Double) {
        currentAngle = angle
    }
    
    public func penUp() {
        isPenDown = false
    }
    
    public func penDown() {
        isPenDown = true
    }
    
    public func setColor(_ hexOrName: String) {
        let color = parseColor(hexOrName)
        currentColor = color
        currentFillColor = color
    }
    
    public func setPenSize(_ size: Double) {
        currentPenWidth = max(1.0, CGFloat(size))
    }
    
    public func circle(radius: Double, extent: Double = 360.0, steps: Int = 36) {
        // Approximate circle with polygon steps
        let stepCount = max(8, Int(abs(extent) / 360.0 * Double(steps)))
        let stepLength = 2.0 * .pi * radius * (abs(extent) / 360.0) / Double(stepCount)
        let stepAngle = extent / Double(stepCount)
        
        // Turtle circle draws counterclockwise (left turn) for positive radius
        left(degrees: stepAngle / 2.0)
        for _ in 0..<stepCount {
            forward(distance: stepLength)
            left(degrees: stepAngle)
        }
        right(degrees: stepAngle / 2.0)
    }
    
    public func beginFill() {
        isFilling = true
        currentFillPoints = [currentPosition]
    }
    
    public func endFill() {
        if isFilling && currentFillPoints.count >= 3 {
            polygons.append(TurtlePolygon(points: currentFillPoints, fillColor: currentFillColor))
        }
        isFilling = false
        currentFillPoints.removeAll()
    }
    
    private func parseColor(_ name: String) -> Color {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if trimmed.hasPrefix("#") {
            return Color(hex: trimmed)
        }
        switch trimmed {
        case "red": return .red
        case "green": return .green
        case "blue": return .blue
        case "yellow": return .yellow
        case "orange": return .orange
        case "purple": return .purple
        case "pink": return .pink
        case "cyan": return .cyan
        case "black": return .black
        case "white": return .white
        case "gray", "grey": return .gray
        default:
            return .black
        }
    }
}
