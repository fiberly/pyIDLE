import Foundation
import SwiftUI
import Combine

#if canImport(WebKit)
import WebKit
#endif

@MainActor
public class PythonEngine: ObservableObject {
    @Published public var isReady: Bool = false
    @Published public var isRunning: Bool = false
    @Published public var engineVersion: String = "Python 3.12"
    @Published public var statusMessage: String = "Starting Python 3.12..."
    
    // Shell entries
    @Published public var shellEntries: [ShellEntry] = []
    
    // Interactive input() state
    @Published public var isWaitingForInput: Bool = false
    @Published public var inputPromptText: String = ""
    @Published public var inputResponseText: String = ""
    
    // Command history
    @Published public var commandHistory: [String] = []
    @Published public var historyPointer: Int = -1
    
    // Turtle Graphics
    @Published public var turtleState = TurtleState()
    
    // Low level web view runner callback
    public var executeJSScript: ((String) -> Void)?
    
    public init() {
        appendInitialBanner()
    }
    
    public func appendInitialBanner() {
        shellEntries = [
            ShellEntry(kind: .system, text: "Python 3.12.2 (main) [Pyodide CPython on iPadOS]\nType \"help\", \"copyright\", \"credits\" or \"license()\" for more information."),
            ShellEntry(kind: .prompt, text: ">>> ")
        ]
    }
    
    // MARK: - Script Execution
    
    public func runScript(code: String, filename: String = "main.py", showRestartBanner: Bool = false, virtualFiles: [String: String] = [:]) {
        let cleanCode = sanitizePythonInput(code)
        
        if showRestartBanner {
            let header = "================================ RESTART: \(filename) ================================"
            appendEntry(kind: .system, text: header)
        }
        
        isRunning = true
        
        // Encode code, files, and filename safely via JSON
        if let jsonData = try? JSONSerialization.data(withJSONObject: [cleanCode, virtualFiles, filename], options: []),
           let jsonStr = String(data: jsonData, encoding: .utf8) {
            let jsCall = "executePythonCode(\(jsonStr)[0], false, \(jsonStr)[1], \(jsonStr)[2]);"
            executeJSScript?(jsCall)
        }
    }
    
    // MARK: - Interactive REPL
    
    public func executeREPLCommand(_ command: String) {
        let cleanCommand = sanitizePythonInput(command)
        let trimmed = cleanCommand.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            appendEntry(kind: .prompt, text: ">>> ")
            return
        }
        
        // Add to history
        if commandHistory.last != cleanCommand {
            commandHistory.append(cleanCommand)
        }
        historyPointer = commandHistory.count
        
        // Show command in shell
        appendEntry(kind: .prompt, text: ">>> \(cleanCommand)")
        
        isRunning = true
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: [cleanCommand], options: []),
           let jsonStr = String(data: jsonData, encoding: .utf8) {
            let jsCall = "executePythonCode(\(jsonStr)[0], true);"
            executeJSScript?(jsCall)
        }
    }
    
    // MARK: - Input Handling
    
    public func submitInput(_ text: String) {
        guard isWaitingForInput else { return }
        
        let cleanText = sanitizePythonInput(text)
        isWaitingForInput = false
        appendEntry(kind: .userTyped, text: "\(cleanText)\n")
        
        if let jsonData = try? JSONSerialization.data(withJSONObject: [cleanText], options: []),
           let jsonStr = String(data: jsonData, encoding: .utf8) {
            let jsCall = "provideInputResponse(\(jsonStr)[0]);"
            executeJSScript?(jsCall)
        }
    }
    
    // MARK: - Shell Actions
    
    public func restartShell() {
        appendEntry(kind: .system, text: "================================ RESTART: Shell ================================")
        turtleState.reset()
        executeJSScript?("restartEnvironment();")
        appendEntry(kind: .prompt, text: ">>> ")
    }
    
    public func clearShell() {
        shellEntries.removeAll()
        appendEntry(kind: .prompt, text: ">>> ")
    }
    
    public func interrupt() {
        if isRunning {
            isRunning = false
            appendEntry(kind: .stderr, text: "\nKeyboardInterrupt\n")
            appendEntry(kind: .prompt, text: ">>> ")
        }
    }
    
    // MARK: - History Navigation
    
    public func previousHistoryCommand() -> String? {
        guard !commandHistory.isEmpty else { return nil }
        if historyPointer > 0 {
            historyPointer -= 1
            return commandHistory[historyPointer]
        } else if historyPointer == 0 {
            return commandHistory[0]
        }
        return nil
    }
    
    public func nextHistoryCommand() -> String? {
        guard !commandHistory.isEmpty else { return nil }
        if historyPointer < commandHistory.count - 1 {
            historyPointer += 1
            return commandHistory[historyPointer]
        } else {
            historyPointer = commandHistory.count
            return ""
        }
    }
    
    // MARK: - Bridge Message Handlers
    
    public func handleBridgeMessage(_ body: [String: Any]) {
        guard let type = body["type"] as? String else { return }
        
        switch type {
        case "ready":
            isReady = true
            if let ver = body["version"] as? String {
                engineVersion = ver
            }
            statusMessage = "Python 3.12 Engine Ready"
            
        case "status":
            if let msg = body["message"] as? String {
                statusMessage = msg
            }
            
        case "stdout":
            if let text = body["text"] as? String {
                appendEntry(kind: .stdout, text: text)
            }
            
        case "stderr":
            if let text = body["text"] as? String {
                appendEntry(kind: .stderr, text: text)
            }
            
        case "result":
            if let text = body["text"] as? String {
                appendEntry(kind: .result, text: text)
            }
            
        case "inputPrompt":
            let prompt = body["prompt"] as? String ?? ""
            inputPromptText = prompt
            isWaitingForInput = true
            appendEntry(kind: .inputPrompt, text: prompt)
            
        case "turtle":
            handleTurtleCommand(body)
            
        case "executionStarted":
            isRunning = true
            
        case "executionFinished":
            isRunning = false
            appendEntry(kind: .prompt, text: ">>> ")
            
        default:
            break
        }
    }
    
    private func handleTurtleCommand(_ dict: [String: Any]) {
        guard let action = dict["action"] as? String else { return }
        
        switch action {
        case "forward":
            if let d = dict["distance"] as? Double { turtleState.forward(distance: d) }
        case "backward":
            if let d = dict["distance"] as? Double { turtleState.backward(distance: d) }
        case "right":
            if let deg = dict["degrees"] as? Double { turtleState.right(degrees: deg) }
        case "left":
            if let deg = dict["degrees"] as? Double { turtleState.left(degrees: deg) }
        case "goto":
            if let x = dict["x"] as? Double, let y = dict["y"] as? Double {
                turtleState.goto(x: x, y: y)
            }
        case "setheading":
            if let a = dict["angle"] as? Double { turtleState.setHeading(angle: a) }
        case "penup":
            turtleState.penUp()
        case "pendown":
            turtleState.penDown()
        case "color":
            if let c = dict["color"] as? String { turtleState.setColor(c) }
        case "pensize":
            if let s = dict["size"] as? Double { turtleState.setPenSize(s) }
        case "circle":
            let r = dict["radius"] as? Double ?? 50.0
            let ext = dict["extent"] as? Double ?? 360.0
            let steps = dict["steps"] as? Int ?? 36
            turtleState.circle(radius: r, extent: ext, steps: steps)
        case "begin_fill":
            turtleState.beginFill()
        case "end_fill":
            turtleState.endFill()
        case "clear":
            turtleState.clear()
        case "reset":
            turtleState.reset()
        default:
            break
        }
    }
    
    private func appendEntry(kind: ShellEntryKind, text: String) {
        if let last = shellEntries.last, last.kind == kind, kind == .stdout || kind == .stderr {
            let updatedText = last.text + text
            shellEntries[shellEntries.count - 1] = ShellEntry(id: last.id, kind: kind, text: updatedText, timestamp: last.timestamp)
        } else {
            shellEntries.append(ShellEntry(kind: kind, text: text))
        }
    }
    
    // Converts iOS smart quotes, typographic dashes, and CRLF linebreaks into valid Python ASCII equivalents
    public func sanitizePythonInput(_ string: String) -> String {
        return string
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
            .replacingOccurrences(of: "“", with: "\"")
            .replacingOccurrences(of: "”", with: "\"")
            .replacingOccurrences(of: "„", with: "\"")
            .replacingOccurrences(of: "‘", with: "'")
            .replacingOccurrences(of: "’", with: "'")
            .replacingOccurrences(of: "—", with: "--")
            .replacingOccurrences(of: "–", with: "-")
    }
}
