// FloppyDiskIcon is defined in PythonEditorView.swift
