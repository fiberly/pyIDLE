import SwiftUI

#if canImport(UIKit)
import UIKit
public typealias PlatformFont = UIFont
#elseif canImport(AppKit)
import AppKit
public typealias PlatformFont = NSFont
#endif

public final class PythonSyntaxHighlighter {
    public static let shared = PythonSyntaxHighlighter()
    
    private let keywords = [
        "False", "None", "True", "and", "as", "assert", "async", "await",
        "break", "class", "continue", "def", "del", "elif", "else", "except",
        "finally", "for", "from", "global", "if", "import", "in", "is", "lambda",
        "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with",
        "yield", "match", "case"
    ]
    
    private let builtins = [
        "abs", "aiter", "all", "anext", "any", "ascii", "bin", "bool", "breakpoint",
        "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex",
        "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter",
        "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash",
        "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter",
        "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object",
        "oct", "open", "ord", "pow", "print", "property", "range", "repr", "reversed",
        "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum",
        "super", "tuple", "type", "vars", "zip", "self", "cls"
    ]
    
    private var keywordRegex: NSRegularExpression?
    private var builtinRegex: NSRegularExpression?
    private var numberRegex: NSRegularExpression?
    private var commentRegex: NSRegularExpression?
    private var stringRegex: NSRegularExpression?
    private var defClassRegex: NSRegularExpression?
    private var decoratorRegex: NSRegularExpression?
    
    private init() {
        let kwPattern = "\\b(" + keywords.joined(separator: "|") + ")\\b"
        let biPattern = "\\b(" + builtins.joined(separator: "|") + ")\\b"
        let numPattern = "\\b(0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+|\\d+(\\.\\d+)?([eE][+-]?\\d+)?)\\b"
        let commentPattern = "#.*$"
        let strPattern = "(\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|(?:f|r|b|u)?\"(?:[^\"\\\\]|\\\\.)*\"|(?:f|r|b|u)?'(?:[^'\\\\]|\\\\.)*')"
        let defClassPattern = "\\b(def|class)\\s+([a-zA-Z_][a-zA-Z0-9_]*)"
        let decoratorPattern = "@[a-zA-Z_][a-zA-Z0-9_.]*"
        
        keywordRegex = try? NSRegularExpression(pattern: kwPattern)
        builtinRegex = try? NSRegularExpression(pattern: biPattern)
        numberRegex = try? NSRegularExpression(pattern: numPattern)
        commentRegex = try? NSRegularExpression(pattern: commentPattern, options: .anchorsMatchLines)
        stringRegex = try? NSRegularExpression(pattern: strPattern)
        defClassRegex = try? NSRegularExpression(pattern: defClassPattern)
        decoratorRegex = try? NSRegularExpression(pattern: decoratorPattern)
    }
    
    #if canImport(UIKit)
    public func highlight(code: String, font: UIFont, theme: EditorTheme) -> NSAttributedString {
        let attributed = NSMutableAttributedString(
            string: code,
            attributes: [
                .font: font,
                .foregroundColor: theme.uiTextColor
            ]
        )
        
        let range = NSRange(location: 0, length: (code as NSString).length)
        guard range.length > 0 else { return attributed }
        
        // 1. Numbers
        if let numberRegex = numberRegex {
            for match in numberRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiNumberColor, range: match.range)
            }
        }
        
        // 2. Builtins
        if let builtinRegex = builtinRegex {
            for match in builtinRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiBuiltinColor, range: match.range)
            }
        }
        
        // 3. Keywords
        if let keywordRegex = keywordRegex {
            for match in keywordRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiKeywordColor, range: match.range)
                attributed.addAttribute(.font, value: UIFont.monospacedSystemFont(ofSize: font.pointSize, weight: .bold), range: match.range)
            }
        }
        
        // 4. Function & Class definitions
        if let defClassRegex = defClassRegex {
            for match in defClassRegex.matches(in: code, range: range) {
                if match.numberOfRanges > 2 {
                    let nameRange = match.range(at: 2)
                    attributed.addAttribute(.foregroundColor, value: theme.uiDefinitionColor, range: nameRange)
                    attributed.addAttribute(.font, value: UIFont.monospacedSystemFont(ofSize: font.pointSize, weight: .bold), range: nameRange)
                }
            }
        }
        
        // 5. Decorators
        if let decoratorRegex = decoratorRegex {
            for match in decoratorRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiDecoratorColor, range: match.range)
            }
        }
        
        // 6. Strings
        if let stringRegex = stringRegex {
            for match in stringRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiStringColor, range: match.range)
                attributed.addAttribute(.font, value: font, range: match.range)
            }
        }
        
        // 7. Comments
        if let commentRegex = commentRegex {
            for match in commentRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: theme.uiCommentColor, range: match.range)
                attributed.addAttribute(.font, value: UIFont.italicSystemFont(ofSize: font.pointSize), range: match.range)
            }
        }
        
        return attributed
    }
    #elseif canImport(AppKit)
    public func highlight(code: String, font: NSFont, theme: EditorTheme) -> NSAttributedString {
        let nsTextColor = NSColor(theme.textColor)
        let attributed = NSMutableAttributedString(
            string: code,
            attributes: [
                .font: font,
                .foregroundColor: nsTextColor
            ]
        )
        
        let range = NSRange(location: 0, length: (code as NSString).length)
        guard range.length > 0 else { return attributed }
        
        if let numberRegex = numberRegex {
            for match in numberRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.numberColor), range: match.range)
            }
        }
        
        if let builtinRegex = builtinRegex {
            for match in builtinRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.builtinColor), range: match.range)
            }
        }
        
        if let keywordRegex = keywordRegex {
            for match in keywordRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.keywordColor), range: match.range)
                attributed.addAttribute(.font, value: NSFont.monospacedSystemFont(ofSize: font.pointSize, weight: .bold), range: match.range)
            }
        }
        
        if let defClassRegex = defClassRegex {
            for match in defClassRegex.matches(in: code, range: range) {
                if match.numberOfRanges > 2 {
                    let nameRange = match.range(at: 2)
                    attributed.addAttribute(.foregroundColor, value: NSColor(theme.definitionColor), range: nameRange)
                    attributed.addAttribute(.font, value: NSFont.monospacedSystemFont(ofSize: font.pointSize, weight: .bold), range: nameRange)
                }
            }
        }
        
        if let decoratorRegex = decoratorRegex {
            for match in decoratorRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.decoratorColor), range: match.range)
            }
        }
        
        if let stringRegex = stringRegex {
            for match in stringRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.stringColor), range: match.range)
                attributed.addAttribute(.font, value: font, range: match.range)
            }
        }
        
        if let commentRegex = commentRegex {
            for match in commentRegex.matches(in: code, range: range) {
                attributed.addAttribute(.foregroundColor, value: NSColor(theme.commentColor), range: match.range)
            }
        }
        
        return attributed
    }
    #endif
}
