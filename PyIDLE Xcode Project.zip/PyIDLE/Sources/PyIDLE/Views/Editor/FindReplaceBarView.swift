import SwiftUI

public struct FindReplaceBarView: View {
    @Binding public var searchText: String
    @Binding public var replaceText: String
    @Binding public var isPresented: Bool
    public var onFindNext: () -> Void
    public var onFindPrevious: () -> Void
    public var onReplace: () -> Void
    public var onReplaceAll: () -> Void
    public var theme: EditorTheme
    
    @State private var showReplaceRow: Bool = false
    
    public init(
        searchText: Binding<String>,
        replaceText: Binding<String>,
        isPresented: Binding<Bool>,
        theme: EditorTheme,
        onFindNext: @escaping () -> Void,
        onFindPrevious: @escaping () -> Void,
        onReplace: @escaping () -> Void,
        onReplaceAll: @escaping () -> Void
    ) {
        self._searchText = searchText
        self._replaceText = replaceText
        self._isPresented = isPresented
        self.theme = theme
        self.onFindNext = onFindNext
        self.onFindPrevious = onFindPrevious
        self.onReplace = onReplace
        self.onReplaceAll = onReplaceAll
    }
    
    public var body: some View {
        VStack(spacing: 6) {
            // Find Row
            HStack(spacing: 8) {
                Button(action: {
                    withAnimation { showReplaceRow.toggle() }
                }) {
                    Image(systemName: showReplaceRow ? "chevron.down" : "chevron.right")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.secondary)
                }
                
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                    .font(.system(size: 13))
                
                TextField("Find in script...", text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 14, design: .monospaced))
                    .disableTextCapitalization()
                    .autocorrectionDisabled(true)
                
                Button(action: onFindPrevious) {
                    Image(systemName: "chevron.up")
                        .font(.system(size: 13, weight: .medium))
                }
                .disabled(searchText.isEmpty)
                
                Button(action: onFindNext) {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .medium))
                }
                .disabled(searchText.isEmpty)
                
                Button(action: {
                    isPresented = false
                    searchText = ""
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.secondary)
                        .font(.system(size: 14))
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.secondary.opacity(0.12))
            .cornerRadius(8)
            
            // Replace Row
            if showReplaceRow {
                HStack(spacing: 8) {
                    Image(systemName: "arrow.2.squarepath")
                        .foregroundColor(.secondary)
                        .font(.system(size: 13))
                    
                    TextField("Replace with...", text: $replaceText)
                        .textFieldStyle(.plain)
                        .font(.system(size: 14, design: .monospaced))
                        .disableTextCapitalization()
                        .autocorrectionDisabled(true)
                    
                    Button("Replace", action: onReplace)
                        .font(.system(size: 12, weight: .semibold))
                        .disabled(searchText.isEmpty)
                    
                    Button("All", action: onReplaceAll)
                        .font(.system(size: 12, weight: .semibold))
                        .disabled(searchText.isEmpty)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.secondary.opacity(0.12))
                .cornerRadius(8)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(8)
        .background(theme.gutterBackgroundColor)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(theme.separatorColor),
            alignment: .bottom
        )
    }
}
