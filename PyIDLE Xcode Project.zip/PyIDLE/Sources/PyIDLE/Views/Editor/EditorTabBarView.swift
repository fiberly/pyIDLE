import SwiftUI

public struct EditorTabBarView: View {
    @Binding public var files: [PythonFile]
    @Binding public var activeFileId: UUID
    public var onNewFile: () -> Void
    public var onCloseFile: (UUID) -> Void
    public var theme: EditorTheme
    
    public init(
        files: Binding<[PythonFile]>,
        activeFileId: Binding<UUID>,
        theme: EditorTheme,
        onNewFile: @escaping () -> Void,
        onCloseFile: @escaping (UUID) -> Void
    ) {
        self._files = files
        self._activeFileId = activeFileId
        self.theme = theme
        self.onNewFile = onNewFile
        self.onCloseFile = onCloseFile
    }
    
    public var body: some View {
        HStack(spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 2) {
                    ForEach(files) { file in
                        let isActive = file.id == activeFileId
                        
                        Button(action: {
                            activeFileId = file.id
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "doc.text.fill")
                                    .font(.system(size: 11))
                                    .foregroundColor(isActive ? .blue : .secondary)
                                
                                Text(file.titleWithStatus)
                                    .font(.system(size: 13, weight: isActive ? .semibold : .regular, design: .monospaced))
                                    .foregroundColor(isActive ? theme.textColor : theme.textColor.opacity(0.6))
                                
                                if files.count > 1 {
                                    Button(action: {
                                        onCloseFile(file.id)
                                    }) {
                                        Image(systemName: "xmark")
                                            .font(.system(size: 10, weight: .bold))
                                            .foregroundColor(theme.textColor.opacity(0.4))
                                            .padding(2)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(isActive ? theme.backgroundColor : theme.gutterBackgroundColor.opacity(0.7))
                            .clipShape(UnevenRoundedRectangle(topLeadingRadius: 6, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 6))
                            .overlay(
                                Rectangle()
                                    .frame(height: isActive ? 2 : 0)
                                    .foregroundColor(.blue),
                                alignment: .bottom
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 6)
                .padding(.top, 4)
            }
            
            // New Tab button
            Button(action: onNewFile) {
                Image(systemName: "plus")
                    .font(.system(size: 12, weight: .semibold))
                    .padding(8)
                    .background(Color.secondary.opacity(0.15))
                    .clipShape(Circle())
            }
            .buttonStyle(.plain)
            .padding(.trailing, 8)
        }
        .background(theme.gutterBackgroundColor)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(theme.separatorColor),
            alignment: .bottom
        )
    }
}
