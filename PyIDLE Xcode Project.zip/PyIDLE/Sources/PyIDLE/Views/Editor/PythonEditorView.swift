import SwiftUI

public struct PythonEditorView: View {
    @Binding public var files: [PythonFile]
    @Binding public var activeFileId: UUID
    public var theme: EditorTheme
    public var fontSize: CGFloat
    public var fontName: String
    public var onRun: (PythonFile) -> Void
    public var onSave: (PythonFile) -> Void
    public var onNewFile: () -> Void
    public var onCloseFile: (UUID) -> Void
    
    @State private var showFindReplace: Bool = false
    @State private var searchText: String = ""
    @State private var replaceText: String = ""
    @State private var currentCursorPos: Int = 0
    
    public init(
        files: Binding<[PythonFile]>,
        activeFileId: Binding<UUID>,
        theme: EditorTheme,
        fontSize: CGFloat = 15,
        fontName: String = "SF Mono",
        onRun: @escaping (PythonFile) -> Void,
        onSave: @escaping (PythonFile) -> Void,
        onNewFile: @escaping () -> Void,
        onCloseFile: @escaping (UUID) -> Void
    ) {
        self._files = files
        self._activeFileId = activeFileId
        self.theme = theme
        self.fontSize = fontSize
        self.fontName = fontName
        self.onRun = onRun
        self.onSave = onSave
        self.onNewFile = onNewFile
        self.onCloseFile = onCloseFile
    }
    
    private var activeFileBinding: Binding<PythonFile>? {
        guard let index = files.firstIndex(where: { $0.id == activeFileId }) else { return nil }
        return $files[index]
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            // Editor Top Action Bar
            HStack(spacing: 12) {
                // Run Module Button (IDLE F5 style)
                Button(action: {
                    if let active = files.first(where: { $0.id == activeFileId }) {
                        onRun(active)
                    }
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "play.fill")
                            .font(.system(size: 11, weight: .bold))
                        Text("Run")
                            .font(.system(size: 12, weight: .bold))
                        Text("(F5)")
                            .font(.system(size: 10, design: .monospaced))
                            .opacity(0.8)
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(Color.green)
                    .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .fixedSize()
                
                // Save Button
                Button(action: {
                    if let active = files.first(where: { $0.id == activeFileId }) {
                        onSave(active)
                    }
                }) {
                    FloppyDiskIcon(size: 15)
                        .padding(6)
                        .background(Color.secondary.opacity(0.15))
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help("Save (Cmd+S)")
                
                // Find & Replace Toggle
                Button(action: {
                    withAnimation { showFindReplace.toggle() }
                }) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(showFindReplace ? .blue : .primary)
                        .padding(6)
                        .background(Color.secondary.opacity(0.15))
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help("Find & Replace (Cmd+F)")
                
                Spacer()
                
                // Line / Column status readout
                Text(cursorReadout)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(theme.gutterBackgroundColor)
            .overlay(
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(theme.separatorColor),
                alignment: .bottom
            )
            
            // Tab Bar
            EditorTabBarView(
                files: $files,
                activeFileId: $activeFileId,
                theme: theme,
                onNewFile: onNewFile,
                onCloseFile: onCloseFile
            )
            
            // Find / Replace Bar
            if showFindReplace {
                FindReplaceBarView(
                    searchText: $searchText,
                    replaceText: $replaceText,
                    isPresented: $showFindReplace,
                    theme: theme,
                    onFindNext: handleFindNext,
                    onFindPrevious: handleFindPrevious,
                    onReplace: handleReplace,
                    onReplaceAll: handleReplaceAll
                )
            }
            
            // Active Code Editor
            if let activeBinding = activeFileBinding {
                CodeEditorRepresentable(
                    text: Binding(
                        get: { activeBinding.wrappedValue.content },
                        set: { newText in
                            activeBinding.wrappedValue.updateContent(newText)
                        }
                    ),
                    theme: theme,
                    fontSize: fontSize,
                    fontName: fontName,
                    isEditable: true,
                    onCursorChange: { pos in
                        currentCursorPos = pos
                    }
                )
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "doc.badge.plus")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    Text("No file open")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    Button("Create New Python Script", action: onNewFile)
                        .buttonStyle(.borderedProminent)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(theme.backgroundColor)
            }
        }
    }
    
    private var cursorReadout: String {
        guard let active = files.first(where: { $0.id == activeFileId }) else { return "" }
        let text = active.content as NSString
        let validPos = min(currentCursorPos, text.length)
        let sub = text.substring(to: validPos)
        let lines = sub.components(separatedBy: "\n")
        let lineNum = lines.count
        let colNum = (lines.last?.count ?? 0) + 1
        return "Ln \(lineNum), Col \(colNum)"
    }
    
    private func handleFindNext() {
        // Implement next match search
    }
    
    private func handleFindPrevious() {
        // Implement previous match search
    }
    
    private func handleReplace() {
        guard let activeBinding = activeFileBinding, !searchText.isEmpty else { return }
        let current = activeBinding.wrappedValue.content
        if let range = current.range(of: searchText) {
            let updated = current.replacingCharacters(in: range, with: replaceText)
            activeBinding.wrappedValue.updateContent(updated)
        }
    }
    
    private func handleReplaceAll() {
        guard let activeBinding = activeFileBinding, !searchText.isEmpty else { return }
        let current = activeBinding.wrappedValue.content
        let updated = current.replacingOccurrences(of: searchText, with: replaceText)
        activeBinding.wrappedValue.updateContent(updated)
    }
}

// MARK: - Vector Floppy Disk Icon
public struct FloppyDiskIcon: View {
    public var size: CGFloat
    
    public init(size: CGFloat = 16) {
        self.size = size
    }
    
    public var body: some View {
        Canvas { context, sz in
            let w = sz.width
            let h = sz.height
            let corner = min(w, h) * 0.09
            let chamfer = min(w, h) * 0.20
            
            // 1. Disk Outer Shell (with top-right chamfer notch)
            var bodyPath = Path()
            bodyPath.move(to: CGPoint(x: corner, y: 0))
            bodyPath.addLine(to: CGPoint(x: w - chamfer, y: 0))
            bodyPath.addLine(to: CGPoint(x: w, y: chamfer))
            bodyPath.addLine(to: CGPoint(x: w, y: h - corner))
            bodyPath.addArc(center: CGPoint(x: w - corner, y: h - corner), radius: corner, startAngle: .degrees(0), endAngle: .degrees(90), clockwise: false)
            bodyPath.addLine(to: CGPoint(x: corner, y: h))
            bodyPath.addArc(center: CGPoint(x: corner, y: h - corner), radius: corner, startAngle: .degrees(90), endAngle: .degrees(180), clockwise: false)
            bodyPath.addLine(to: CGPoint(x: 0, y: corner))
            bodyPath.addArc(center: CGPoint(x: corner, y: corner), radius: corner, startAngle: .degrees(180), endAngle: .degrees(270), clockwise: false)
            bodyPath.closeSubpath()
            
            // 2. Top Metal Shutter Cutout Window
            let shutterRect = CGRect(x: w * 0.22, y: 0, width: w * 0.54, height: h * 0.38)
            let shutterPath = Path(roundedRect: shutterRect, cornerRadius: w * 0.02)
            
            // 3. Shutter Slider Tab Notch
            let notchRect = CGRect(x: w * 0.32, y: h * 0.06, width: w * 0.12, height: h * 0.24)
            let notchPath = Path(roundedRect: notchRect, cornerRadius: w * 0.02)
            
            // 4. Bottom Label Sticker Cutout Window
            let labelRect = CGRect(x: w * 0.16, y: h * 0.46, width: w * 0.68, height: h * 0.46)
            let labelPath = Path(roundedRect: labelRect, cornerRadius: w * 0.04)
            
            // Combine with Even-Odd fill rule so cutouts are transparent
            var combinedPath = Path()
            combinedPath.addPath(bodyPath)
            combinedPath.addPath(shutterPath)
            combinedPath.addPath(notchPath)
            combinedPath.addPath(labelPath)
            
            context.fill(combinedPath, with: .foreground, style: FillStyle(eoFill: true))
        }
        .frame(width: size, height: size)
    }
}
