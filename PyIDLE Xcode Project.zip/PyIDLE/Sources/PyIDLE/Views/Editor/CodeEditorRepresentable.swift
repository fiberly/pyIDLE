import SwiftUI

#if canImport(UIKit)
import UIKit

public struct CodeEditorRepresentable: UIViewRepresentable {
    @Binding public var text: String
    public var theme: EditorTheme
    public var fontSize: CGFloat
    public var fontName: String
    public var isEditable: Bool
    public var onCursorChange: ((Int) -> Void)?
    
    public init(
        text: Binding<String>,
        theme: EditorTheme,
        fontSize: CGFloat = 15,
        fontName: String = "SF Mono",
        isEditable: Bool = true,
        onCursorChange: ((Int) -> Void)? = nil
    ) {
        self._text = text
        self.theme = theme
        self.fontSize = fontSize
        self.fontName = fontName
        self.isEditable = isEditable
        self.onCursorChange = onCursorChange
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    public func makeUIView(context: Context) -> CodeEditorContainerView {
        let container = CodeEditorContainerView(
            theme: theme,
            fontSize: fontSize,
            fontName: fontName,
            isEditable: isEditable
        )
        container.textView.delegate = context.coordinator
        context.coordinator.containerView = container
        
        container.setText(text)
        return container
    }
    
    public func updateUIView(_ uiView: CodeEditorContainerView, context: Context) {
        context.coordinator.parent = self
        uiView.updateTheme(theme, fontSize: fontSize, fontName: fontName)
        if uiView.textView.text != text {
            uiView.setText(text)
        }
    }
    
    public class Coordinator: NSObject, UITextViewDelegate {
        var parent: CodeEditorRepresentable
        weak var containerView: CodeEditorContainerView?
        private var isInternalUpdating = false
        
        init(_ parent: CodeEditorRepresentable) {
            self.parent = parent
        }
        
        public func textViewDidChange(_ textView: UITextView) {
            guard !isInternalUpdating else { return }
            parent.text = textView.text
            containerView?.updateLineNumbers()
            containerView?.rehighlight()
        }
        
        public func textViewDidChangeSelection(_ textView: UITextView) {
            let cursor = textView.selectedRange.location
            parent.onCursorChange?(cursor)
            containerView?.updateCurrentLineHighlight()
        }
        
        public func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            if text == "\n" {
                let currentText = textView.text as NSString
                let lineRange = currentText.lineRange(for: range)
                let currentLine = currentText.substring(with: lineRange)
                
                var indent = ""
                for char in currentLine {
                    if char == " " {
                        indent.append(" ")
                    } else if char == "\t" {
                        indent.append("    ")
                    } else {
                        break
                    }
                }
                
                let trimmedLine = currentLine.trimmingCharacters(in: .whitespacesAndNewlines)
                if trimmedLine.hasSuffix(":") {
                    indent += "    "
                }
                
                let insertString = "\n" + indent
                textView.replace(textView.textRange(from: textView.position(from: textView.beginningOfDocument, offset: range.location)!, to: textView.position(from: textView.beginningOfDocument, offset: range.location + range.length)!)!, withText: insertString)
                
                return false
            }
            
            if text == "\t" {
                textView.insertText("    ")
                return false
            }
            
            let pairs: [String: String] = [
                "(": ")",
                "[": "]",
                "{": "}",
                "\"": "\"",
                "'": "'"
            ]
            
            if let closing = pairs[text], range.length == 0 {
                textView.insertText(text + closing)
                if let newPos = textView.position(from: textView.beginningOfDocument, offset: range.location + text.count) {
                    textView.selectedTextRange = textView.textRange(from: newPos, to: newPos)
                }
                return false
            }
            
            if text == "" && range.length == 1 {
                let currentText = textView.text as NSString
                if range.location >= 3 {
                    let prevFourRange = NSRange(location: range.location - 3, length: 4)
                    if prevFourRange.location + prevFourRange.length <= currentText.length {
                        let substring = currentText.substring(with: prevFourRange)
                        if substring == "    " {
                            textView.replace(textView.textRange(from: textView.position(from: textView.beginningOfDocument, offset: prevFourRange.location)!, to: textView.position(from: textView.beginningOfDocument, offset: range.location + 1)!)!, withText: "")
                            return false
                        }
                    }
                }
            }
            
            return true
        }
    }
}

public class CodeEditorContainerView: UIView {
    public let textView = UITextView()
    private let lineNumbersGutter = UITextView()
    private let dividerView = UIView()
    
    private var theme: EditorTheme
    private var fontSize: CGFloat
    private var fontName: String
    
    public init(theme: EditorTheme, fontSize: CGFloat, fontName: String, isEditable: Bool) {
        self.theme = theme
        self.fontSize = fontSize
        self.fontName = fontName
        super.init(frame: .zero)
        
        setupViews(isEditable: isEditable)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getFont() -> UIFont {
        if fontName == "SF Mono" {
            return UIFont.monospacedSystemFont(ofSize: fontSize, weight: .regular)
        } else if let customFont = UIFont(name: fontName, size: fontSize) {
            return customFont
        }
        return UIFont.monospacedSystemFont(ofSize: fontSize, weight: .regular)
    }
    
    private func setupViews(isEditable: Bool) {
        let font = getFont()
        
        lineNumbersGutter.translatesAutoresizingMaskIntoConstraints = false
        lineNumbersGutter.isEditable = false
        lineNumbersGutter.isSelectable = false
        lineNumbersGutter.isScrollEnabled = false
        lineNumbersGutter.textAlignment = .right
        lineNumbersGutter.backgroundColor = theme.uiGutterBackgroundColor
        lineNumbersGutter.textColor = theme.uiGutterTextColor
        lineNumbersGutter.font = font
        lineNumbersGutter.textContainerInset = UIEdgeInsets(top: 10, left: 4, bottom: 10, right: 8)
        
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.isEditable = isEditable
        textView.isSelectable = true
        textView.backgroundColor = theme.uiBackgroundColor
        textView.textColor = theme.uiTextColor
        textView.font = font
        textView.autocapitalizationType = .none
        textView.autocorrectionType = .no
        textView.spellCheckingType = .no
        textView.smartDashesType = .no
        textView.smartQuotesType = .no
        textView.smartInsertDeleteType = .no
        textView.textContainerInset = UIEdgeInsets(top: 10, left: 8, bottom: 10, right: 10)
        
        dividerView.translatesAutoresizingMaskIntoConstraints = false
        dividerView.backgroundColor = theme.uiGutterTextColor.withAlphaComponent(0.2)
        
        addSubview(lineNumbersGutter)
        addSubview(dividerView)
        addSubview(textView)
        
        NSLayoutConstraint.activate([
            lineNumbersGutter.leadingAnchor.constraint(equalTo: leadingAnchor),
            lineNumbersGutter.topAnchor.constraint(equalTo: topAnchor),
            lineNumbersGutter.bottomAnchor.constraint(equalTo: bottomAnchor),
            lineNumbersGutter.widthAnchor.constraint(equalToConstant: 44),
            
            dividerView.leadingAnchor.constraint(equalTo: lineNumbersGutter.trailingAnchor),
            dividerView.topAnchor.constraint(equalTo: topAnchor),
            dividerView.bottomAnchor.constraint(equalTo: bottomAnchor),
            dividerView.widthAnchor.constraint(equalToConstant: 1),
            
            textView.leadingAnchor.constraint(equalTo: dividerView.trailingAnchor),
            textView.topAnchor.constraint(equalTo: topAnchor),
            textView.trailingAnchor.constraint(equalTo: trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        setupKeyboardAccessoryToolbar()
    }
    
    private func setupKeyboardAccessoryToolbar() {
        let hostingController = UIHostingController(rootView: iPadKeyboardToolbar(
            onInsert: { [weak self] str in
                self?.textView.insertText(str)
            },
            onIndent: { [weak self] in
                self?.textView.insertText("    ")
            },
            onDedent: { [weak self] in
                self?.dedentCurrentLine()
            },
            onMoveCursor: { [weak self] delta in
                self?.moveCursor(by: delta)
            },
            onUndo: { [weak self] in
                self?.textView.undoManager?.undo()
            },
            onRedo: { [weak self] in
                self?.textView.undoManager?.redo()
            },
            onDismiss: { [weak self] in
                self?.textView.resignFirstResponder()
            }
        ))
        
        let bar = hostingController.view!
        bar.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 44)
        bar.autoresizingMask = [.flexibleWidth]
        textView.inputAccessoryView = bar
    }
    
    public func setText(_ newText: String) {
        let font = getFont()
        let highlighted = PythonSyntaxHighlighter.shared.highlight(code: newText, font: font, theme: theme)
        let selectedRange = textView.selectedRange
        textView.attributedText = highlighted
        textView.selectedRange = selectedRange
        updateLineNumbers()
    }
    
    public func rehighlight() {
        let currentPos = textView.selectedRange
        let font = getFont()
        let highlighted = PythonSyntaxHighlighter.shared.highlight(code: textView.text, font: font, theme: theme)
        textView.attributedText = highlighted
        textView.selectedRange = currentPos
    }
    
    public func updateLineNumbers() {
        let text = textView.text ?? ""
        let lineCount = max(1, text.components(separatedBy: "\n").count)
        let numberString = (1...lineCount).map { "\($0)" }.joined(separator: "\n")
        lineNumbersGutter.text = numberString
    }
    
    public func updateCurrentLineHighlight() {}
    
    public func updateTheme(_ newTheme: EditorTheme, fontSize: CGFloat, fontName: String) {
        self.theme = newTheme
        self.fontSize = fontSize
        self.fontName = fontName
        
        let font = getFont()
        lineNumbersGutter.backgroundColor = newTheme.uiGutterBackgroundColor
        lineNumbersGutter.textColor = newTheme.uiGutterTextColor
        lineNumbersGutter.font = font
        
        textView.backgroundColor = newTheme.uiBackgroundColor
        textView.textColor = newTheme.uiTextColor
        textView.font = font
        
        rehighlight()
    }
    
    private func dedentCurrentLine() {
        let range = textView.selectedRange
        let currentText = textView.text as NSString
        let lineRange = currentText.lineRange(for: range)
        let line = currentText.substring(with: lineRange)
        
        if line.hasPrefix("    ") {
            let modRange = NSRange(location: lineRange.location, length: 4)
            if let textRange = textView.textRange(from: textView.position(from: textView.beginningOfDocument, offset: modRange.location)!, to: textView.position(from: textView.beginningOfDocument, offset: modRange.location + 4)!) {
                textView.replace(textRange, withText: "")
            }
        }
    }
    
    private func moveCursor(by offset: Int) {
        guard let current = textView.selectedTextRange else { return }
        if let newPos = textView.position(from: current.start, offset: offset) {
            textView.selectedTextRange = textView.textRange(from: newPos, to: newPos)
        }
    }
}

#elseif canImport(AppKit)
import AppKit

public struct CodeEditorRepresentable: NSViewRepresentable {
    @Binding public var text: String
    public var theme: EditorTheme
    public var fontSize: CGFloat
    public var fontName: String
    public var isEditable: Bool
    public var onCursorChange: ((Int) -> Void)?
    
    public init(
        text: Binding<String>,
        theme: EditorTheme,
        fontSize: CGFloat = 15,
        fontName: String = "SF Mono",
        isEditable: Bool = true,
        onCursorChange: ((Int) -> Void)? = nil
    ) {
        self._text = text
        self.theme = theme
        self.fontSize = fontSize
        self.fontName = fontName
        self.isEditable = isEditable
        self.onCursorChange = onCursorChange
    }
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    public func makeNSView(context: Context) -> NSScrollView {
        let scrollView = NSTextView.scrollableTextView()
        guard let textView = scrollView.documentView as? NSTextView else { return scrollView }
        
        textView.delegate = context.coordinator
        textView.isEditable = isEditable
        textView.isSelectable = true
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(ofSize: fontSize, weight: .regular)
        textView.backgroundColor = NSColor(theme.backgroundColor)
        textView.textColor = NSColor(theme.textColor)
        textView.string = text
        
        return scrollView
    }
    
    public func updateNSView(_ nsView: NSScrollView, context: Context) {
        if let textView = nsView.documentView as? NSTextView {
            if textView.string != text {
                textView.string = text
            }
        }
    }
    
    public class Coordinator: NSObject, NSTextViewDelegate {
        var parent: CodeEditorRepresentable
        
        init(_ parent: CodeEditorRepresentable) {
            self.parent = parent
        }
        
        public func textDidChange(_ notification: Notification) {
            guard let textView = notification.object as? NSTextView else { return }
            parent.text = textView.string
        }
    }
}
#endif
