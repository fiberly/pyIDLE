import SwiftUI

public struct KeyboardActionItem: Identifiable {
    public let id = UUID()
    public let title: String
    public let insertText: String?
    public let actionType: ActionType
    
    public enum ActionType {
        case insert(String)
        case indent
        case dedent
        case moveCursorLeft
        case moveCursorRight
        case undo
        case redo
        case dismissKeyboard
    }
}

public struct iPadKeyboardToolbar: View {
    public var onInsert: (String) -> Void
    public var onIndent: () -> Void
    public var onDedent: () -> Void
    public var onMoveCursor: (Int) -> Void
    public var onUndo: () -> Void
    public var onRedo: () -> Void
    public var onDismiss: () -> Void
    
    @State private var selectedTab: Int = 0
    
    private let symbolKeys = [
        "Tab", ":", "(", ")", "[", "]", "{", "}", "\"", "'",
        "=", "+", "-", "*", "/", "%", "==", "!=", "<=", ">=",
        "_", "->", "#", ",", ".", "\\", "|", "&", "!"
    ]
    
    private let snippetKeys = [
        ("def", "def "),
        ("class", "class "),
        ("print", "print()"),
        ("import", "import "),
        ("from", "from "),
        ("self", "self"),
        ("return", "return "),
        ("if", "if "),
        ("elif", "elif "),
        ("else", "else:\n    "),
        ("for", "for i in range():"),
        ("while", "while "),
        ("try", "try:\n    \nexcept Exception as e:\n    print(e)"),
        ("lambda", "lambda "),
        ("with", "with open() as f:"),
        ("async", "async def "),
        ("await", "await ")
    ]
    
    public init(
        onInsert: @escaping (String) -> Void,
        onIndent: @escaping () -> Void,
        onDedent: @escaping () -> Void,
        onMoveCursor: @escaping (Int) -> Void,
        onUndo: @escaping () -> Void,
        onRedo: @escaping () -> Void,
        onDismiss: @escaping () -> Void
    ) {
        self.onInsert = onInsert
        self.onIndent = onIndent
        self.onDedent = onDedent
        self.onMoveCursor = onMoveCursor
        self.onUndo = onUndo
        self.onRedo = onRedo
        self.onDismiss = onDismiss
    }
    
    public var body: some View {
        VStack(spacing: 4) {
            // Segmented mode switcher
            HStack(spacing: 8) {
                // Navigation & Edit controls
                Group {
                    Button(action: onUndo) {
                        Image(systemName: "arrow.uturn.backward")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .accessoryButtonStyle()
                    
                    Button(action: onRedo) {
                        Image(systemName: "arrow.uturn.forward")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .accessoryButtonStyle()
                    
                    Button(action: onIndent) {
                        HStack(spacing: 2) {
                            Image(systemName: "arrow.right.to.line")
                            Text("Tab")
                                .font(.system(size: 13, weight: .bold, design: .monospaced))
                        }
                    }
                    .accessoryButtonStyle()
                    
                    Button(action: onDedent) {
                        HStack(spacing: 2) {
                            Image(systemName: "arrow.left.to.line")
                            Text("Untab")
                                .font(.system(size: 13, weight: .bold, design: .monospaced))
                        }
                    }
                    .accessoryButtonStyle()
                    
                    Button(action: { onMoveCursor(-1) }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .accessoryButtonStyle()
                    
                    Button(action: { onMoveCursor(1) }) {
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                    }
                    .accessoryButtonStyle()
                }
                
                Divider()
                    .frame(height: 20)
                
                // Horizontal scrolling symbols / snippets
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(symbolKeys.filter { $0 != "Tab" }, id: \.self) { sym in
                            Button(action: {
                                if sym == "()" {
                                    onInsert("()")
                                } else if sym == "print()" {
                                    onInsert("print()")
                                } else {
                                    onInsert(sym)
                                }
                            }) {
                                Text(sym)
                                    .font(.system(size: 15, weight: .medium, design: .monospaced))
                            }
                            .accessoryButtonStyle()
                        }
                        
                        Divider()
                            .frame(height: 20)
                        
                        ForEach(snippetKeys, id: \.0) { title, text in
                            Button(action: {
                                onInsert(text)
                            }) {
                                Text(title)
                                    .font(.system(size: 14, weight: .medium, design: .monospaced))
                                    .foregroundColor(.purple)
                            }
                            .accessoryButtonStyle()
                        }
                    }
                    .padding(.horizontal, 4)
                }
                
                // Keyboard dismiss
                Button(action: onDismiss) {
                    Image(systemName: "keyboard.chevron.compact.down")
                        .font(.system(size: 14, weight: .semibold))
                }
                .accessoryButtonStyle()
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
        }
        .background(.ultraThinMaterial)
    }
}

struct AccessoryButtonModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.secondary.opacity(0.18))
            .cornerRadius(6)
            .contentShape(Rectangle())
    }
}

extension View {
    func accessoryButtonStyle() -> some View {
        self.modifier(AccessoryButtonModifier())
    }
}
