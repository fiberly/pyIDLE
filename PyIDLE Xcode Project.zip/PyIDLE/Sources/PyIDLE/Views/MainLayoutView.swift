import SwiftUI
import UniformTypeIdentifiers

public struct MainLayoutView: View {
    @StateObject private var appState = AppState()
    @State private var columnVisibility: NavigationSplitViewVisibility = .all
    
    public init() {}
    
    public var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility) {
            SidebarView(
                selectedTab: $appState.sidebarTab,
                files: $appState.files,
                activeFileId: $appState.activeFileId,
                selectedTheme: $appState.selectedTheme,
                fontSize: $appState.fontSize,
                fontName: $appState.fontName,
                autoPairBrackets: $appState.autoPairBrackets,
                showRestartBanner: $appState.showRestartBanner,
                engineVersion: appState.engine.engineVersion,
                theme: appState.currentTheme,
                onNewFile: { appState.createNewFile() },
                onOpenFileFromDisk: { url in appState.openFile(from: url) },
                onSaveFileToDisk: { file in appState.saveFile(file) },
                onSelectExample: { ex in appState.loadExample(ex) },
                onInsertSnippet: { snippet in appState.insertSnippet(snippet) }
            )
            .navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 380)
        } detail: {
            ZStack {
                // Main Workspace Layout
                VStack(spacing: 0) {
                    workspaceContent
                }
                
                // Background Pyodide Bridge
                PyodideBridgeView(engine: appState.engine)
                    .frame(width: 1, height: 1)
                    .opacity(0.01)
            }
            .background(appState.currentTheme.backgroundColor)
            .toolbar {
                mainToolbarItems
            }
        }
        .preferredColorScheme(appState.currentTheme.isDark ? .dark : .light)
        .fileExporter(
            isPresented: $appState.showFileExporter,
            document: appState.fileToExport,
            contentType: UTType("public.python-script") ?? .plainText,
            defaultFilename: appState.exportFileName
        ) { result in
            switch result {
            case .success(let url):
                let didAccess = url.startAccessingSecurityScopedResource()
                defer {
                    if didAccess {
                        url.stopAccessingSecurityScopedResource()
                    }
                }
                if let idx = appState.files.firstIndex(where: { $0.id == appState.activeFileId }) {
                    appState.files[idx].markSaved(at: url)
                }
            case .failure(let error):
                print("[PyIDLE] Save export error:", error)
            }
        }
    }
    
    // MARK: - Workspace Layout Modes
    
    @ViewBuilder
    private var workspaceContent: some View {
        switch appState.layoutMode {
        case .splitHorizontal:
            HStack(spacing: 0) {
                editorPane
                
                Rectangle()
                    .frame(width: 1)
                    .foregroundColor(appState.currentTheme.separatorColor)
                
                shellPane
            }
            
        case .splitVertical:
            VStack(spacing: 0) {
                editorPane
                
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(appState.currentTheme.separatorColor)
                
                shellPane
            }
            
        case .editorOnly:
            editorPane
            
        case .shellOnly:
            shellPane
            
        case .turtleSplit:
            HStack(spacing: 0) {
                editorPane
                
                Rectangle()
                    .frame(width: 1)
                    .foregroundColor(appState.currentTheme.separatorColor)
                
                VStack(spacing: 0) {
                    TurtleCanvasView(
                        turtleState: appState.engine.turtleState,
                        theme: appState.currentTheme
                    )
                    
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(appState.currentTheme.separatorColor)
                    
                    shellPane
                        .frame(height: 220)
                }
            }
        }
    }
    
    private var editorPane: some View {
        PythonEditorView(
            files: $appState.files,
            activeFileId: $appState.activeFileId,
            theme: appState.currentTheme,
            fontSize: appState.fontSize,
            fontName: appState.fontName,
            onRun: { file in
                appState.runCurrentScript()
            },
            onSave: { file in
                appState.saveFile(file)
            },
            onNewFile: {
                appState.createNewFile()
            },
            onCloseFile: { id in
                appState.closeFile(id: id)
            }
        )
    }
    
    private var shellPane: some View {
        PythonShellView(
            engine: appState.engine,
            theme: appState.currentTheme,
            fontSize: appState.fontSize,
            fontName: appState.fontName
        )
    }
    
    // MARK: - Toolbar Items
    
    @ToolbarContentBuilder
    private var mainToolbarItems: some ToolbarContent {
        ToolbarItemGroup(placement: .primaryAction) {
            // Run Module (Cmd+R or F5)
            Button(action: {
                appState.runCurrentScript()
            }) {
                HStack(spacing: 4) {
                    Image(systemName: "play.fill")
                        .font(.system(size: 13, weight: .bold))
                    Text("Run")
                        .fontWeight(.bold)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(6)
            }
            .keyboardShortcut("r", modifiers: .command)
            .help("Run Module (Cmd+R or F5)")
            
            // Save Script (Cmd+S)
            Button(action: {
                if let active = appState.activeFile {
                    appState.saveFile(active)
                }
            }) {
                HStack(spacing: 5) {
                    FloppyDiskIcon(size: 14)
                    Text("Save")
                        .fontWeight(.semibold)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.secondary.opacity(0.15))
                .foregroundColor(appState.currentTheme.textColor)
                .cornerRadius(6)
            }
            .keyboardShortcut("s", modifiers: .command)
            .help("Save Script (Cmd+S)")
            
            // Restart Shell (Cmd+Shift+R)
            Button(action: {
                appState.engine.restartShell()
            }) {
                Image(systemName: "arrow.clockwise")
            }
            .keyboardShortcut("r", modifiers: [.command, .shift])
            .help("Restart Shell (Cmd+Shift+R)")
            
            // Layout Selector Menu
            Menu {
                ForEach(IDLELayoutMode.allCases) { mode in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            appState.layoutMode = mode
                        }
                    }) {
                        Label(mode.rawValue, systemImage: mode.icon)
                    }
                }
            } label: {
                Image(systemName: appState.layoutMode.icon)
            }
            
            // Theme Selector Menu
            Menu {
                ForEach(ThemeType.allCases) { theme in
                    Button(action: {
                        appState.selectedTheme = theme
                    }) {
                        HStack {
                            Text(theme.rawValue)
                            if appState.selectedTheme == theme {
                                Image(systemName: "checkmark")
                            }
                        }
                    }
                }
            } label: {
                Image(systemName: "paintpalette")
            }
            
            // Quick New Script (Cmd+N)
            Button(action: {
                appState.createNewFile()
            }) {
                Image(systemName: "plus")
            }
            .keyboardShortcut("n", modifiers: .command)
            .help("New File (Cmd+N)")
        }
    }
}
