import SwiftUI

public struct TurtleCanvasView: View {
    @ObservedObject public var turtleState: TurtleState
    public var theme: EditorTheme
    
    @State private var scale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    @State private var lastScale: CGFloat = 1.0
    
    public init(turtleState: TurtleState, theme: EditorTheme) {
        self.turtleState = turtleState
        self.theme = theme
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            // Header Bar
            HStack(spacing: 12) {
                HStack(spacing: 6) {
                    Image(systemName: "paintpalette.fill")
                        .foregroundColor(.green)
                    Text("Turtle Graphics Canvas")
                        .font(.system(size: 13, weight: .bold))
                }
                
                Spacer()
                
                // Zoom Readout
                Text("\(Int(scale * 100))%")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(.secondary)
                
                // Reset View
                Button(action: resetZoomPan) {
                    Image(systemName: "arrow.counterclockwise")
                        .font(.system(size: 12))
                        .padding(6)
                        .background(Color.secondary.opacity(0.15))
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help("Reset Canvas View")
                
                // Clear Canvas
                Button(action: { turtleState.clear() }) {
                    Image(systemName: "trash")
                        .font(.system(size: 12))
                        .padding(6)
                        .background(Color.secondary.opacity(0.15))
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help("Clear Drawing")
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(theme.gutterBackgroundColor)
            .overlay(
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(theme.separatorColor),
                alignment: .bottom
            )
            
            // Canvas View
            GeometryReader { geo in
                let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
                
                ZStack {
                    turtleState.backgroundColor
                        .ignoresSafeArea()
                    
                    // Grid background
                    Canvas { context, size in
                        let gridStep: CGFloat = 40.0 * scale
                        var path = Path()
                        
                        let startX = (center.x + offset.width).truncatingRemainder(dividingBy: gridStep)
                        let startY = (center.y + offset.height).truncatingRemainder(dividingBy: gridStep)
                        
                        for x in stride(from: startX, through: size.width, by: gridStep) {
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x, y: size.height))
                        }
                        for y in stride(from: startY, through: size.height, by: gridStep) {
                            path.move(to: CGPoint(x: 0, y: y))
                            path.addLine(to: CGPoint(x: size.width, y: y))
                        }
                        
                        context.stroke(path, with: .color(Color.gray.opacity(0.12)), lineWidth: 1)
                        
                        // Origin crosshair
                        var cross = Path()
                        cross.move(to: CGPoint(x: center.x + offset.width - 10, y: center.y + offset.height))
                        cross.addLine(to: CGPoint(x: center.x + offset.width + 10, y: center.y + offset.height))
                        cross.move(to: CGPoint(x: center.x + offset.width, y: center.y + offset.height - 10))
                        cross.addLine(to: CGPoint(x: center.x + offset.width, y: center.y + offset.height + 10))
                        context.stroke(cross, with: .color(Color.gray.opacity(0.35)), lineWidth: 1.5)
                    }
                    
                    // Render Vector Shapes & Segments
                    Canvas { context, size in
                        // Render filled polygons
                        for polygon in turtleState.polygons {
                            guard polygon.points.count >= 3 else { continue }
                            var path = Path()
                            let first = polygon.points[0]
                            path.move(to: CGPoint(
                                x: center.x + offset.width + first.x * scale,
                                y: center.y + offset.height + first.y * scale
                            ))
                            for pt in polygon.points.dropFirst() {
                                path.addLine(to: CGPoint(
                                    x: center.x + offset.width + pt.x * scale,
                                    y: center.y + offset.height + pt.y * scale
                                ))
                            }
                            path.closeSubpath()
                            context.fill(path, with: .color(polygon.fillColor))
                        }
                        
                        // Render Line Segments
                        for seg in turtleState.segments {
                            var path = Path()
                            path.move(to: CGPoint(
                                x: center.x + offset.width + seg.start.x * scale,
                                y: center.y + offset.height + seg.start.y * scale
                            ))
                            path.addLine(to: CGPoint(
                                x: center.x + offset.width + seg.end.x * scale,
                                y: center.y + offset.height + seg.end.y * scale
                            ))
                            context.stroke(
                                path,
                                with: .color(seg.color),
                                style: StrokeStyle(lineWidth: max(1.0, seg.width * scale), lineCap: .round, lineJoin: .round)
                            )
                        }
                    }
                    
                    // Current Turtle Indicator
                    if turtleState.isVisible {
                        let turtlePos = CGPoint(
                            x: center.x + offset.width + turtleState.currentPosition.x * scale,
                            y: center.y + offset.height + turtleState.currentPosition.y * scale
                        )
                        
                        TurtleCursorView(angle: turtleState.currentAngle, color: turtleState.currentColor)
                            .position(turtlePos)
                    }
                }
                .contentShape(Rectangle())
                .gesture(
                    SimultaneousGesture(
                        DragGesture()
                            .onChanged { val in
                                offset = CGSize(
                                    width: lastOffset.width + val.translation.width,
                                    height: lastOffset.height + val.translation.height
                                )
                            }
                            .onEnded { _ in
                                lastOffset = offset
                            },
                        MagnificationGesture()
                            .onChanged { val in
                                scale = max(0.2, min(5.0, lastScale * val))
                            }
                            .onEnded { _ in
                                lastScale = scale
                            }
                    )
                )
            }
        }
    }
    
    private func resetZoomPan() {
        withAnimation(.spring()) {
            scale = 1.0
            offset = .zero
            lastScale = 1.0
            lastOffset = .zero
        }
    }
}

// MARK: - Turtle Pointer Cursor
struct TurtleCursorView: View {
    let angle: Double
    let color: Color
    
    var body: some View {
        ZStack {
            // Triangle pointer
            Path { path in
                path.move(to: CGPoint(x: 10, y: 0))
                path.addLine(to: CGPoint(x: -8, y: -6))
                path.addLine(to: CGPoint(x: -4, y: 0))
                path.addLine(to: CGPoint(x: -8, y: 6))
                path.closeSubpath()
            }
            .fill(color)
            
            Path { path in
                path.move(to: CGPoint(x: 10, y: 0))
                path.addLine(to: CGPoint(x: -8, y: -6))
                path.addLine(to: CGPoint(x: -4, y: 0))
                path.addLine(to: CGPoint(x: -8, y: 6))
                path.closeSubpath()
            }
            .stroke(Color.white, lineWidth: 1)
        }
        .frame(width: 20, height: 20)
        .rotationEffect(.degrees(-angle)) // Invert for screen space
    }
}
