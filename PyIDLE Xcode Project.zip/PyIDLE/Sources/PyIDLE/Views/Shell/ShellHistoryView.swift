import SwiftUI

public struct ShellHistoryView: View {
    public let history: [String]
    public var onSelect: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    
    @State private var filterText: String = ""
    
    public init(history: [String], onSelect: @escaping (String) -> Void) {
        self.history = history
        self.onSelect = onSelect
    }
    
    private var filteredHistory: [String] {
        if filterText.isEmpty {
            return history.reversed()
        }
        return history.reversed().filter { $0.localizedCaseInsensitiveContains(filterText) }
    }
    
    public var body: some View {
        NavigationStack {
            VStack {
                if history.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "clock")
                            .font(.system(size: 40))
                            .foregroundColor(.secondary)
                        Text("No command history yet")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(filteredHistory, id: \.self) { cmd in
                            Button(action: {
                                onSelect(cmd)
                                dismiss()
                            }) {
                                HStack {
                                    Text(cmd)
                                        .font(.system(size: 14, design: .monospaced))
                                        .foregroundColor(.primary)
                                    Spacer()
                                    Image(systemName: "arrow.up.left")
                                        .font(.system(size: 12))
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                    .searchable(text: $filterText, prompt: "Search history...")
                }
            }
            .navigationTitle("Shell History")
            #if os(iOS)
            .navigationBarTitleDisplayMode(.inline)
            #endif
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}
