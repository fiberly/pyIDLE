import SwiftUI

public struct PythonShellView: View {
    @ObservedObject public var engine: PythonEngine
    public var theme: EditorTheme
    public var fontSize: CGFloat
    public var fontName: String
    
    @State private var currentInputText: String = ""
    @State private var showHistorySheet: Bool = false
    @FocusState private var isInputFocused: Bool
    
    public init(
        engine: PythonEngine,
        theme: EditorTheme,
        fontSize: CGFloat = 14,
        fontName: String = "SF Mono"
    ) {
        self.engine = engine
        self.theme = theme
        self.fontSize = fontSize
        self.fontName = fontName
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            // Shell Header / Control Bar
            HStack(spacing: 8) {
                HStack(spacing: 4) {
                    Image(systemName: "terminal")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(theme.shellPromptColor)
                    
                    Text("Shell")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(theme.textColor)
                }
                .fixedSize()
                
                // Status Pill
                HStack(spacing: 3) {
                    Circle()
                        .fill(engine.isRunning ? Color.orange : (engine.isReady ? Color.green : Color.yellow))
                        .frame(width: 6, height: 6)
                    Text(engine.isRunning ? "Running" : (engine.isReady ? "Ready" : "Init"))
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.secondary)
                }
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Color.secondary.opacity(0.12))
                .cornerRadius(8)
                .fixedSize()
                
                Spacer(minLength: 4)
                
                // Shell Control Buttons
                HStack(spacing: 4) {
                    // History Button
                    Button(action: { showHistorySheet = true }) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 12))
                            .padding(5)
                            .background(Color.secondary.opacity(0.15))
                            .cornerRadius(5)
                    }
                    .buttonStyle(.plain)
                    .help("History")
                    
                    // Interrupt Button (Ctrl+C)
                    Button(action: { engine.interrupt() }) {
                        Image(systemName: "stop.circle.fill")
                            .font(.system(size: 12))
                            .foregroundColor(.red)
                            .padding(5)
                            .background(Color.secondary.opacity(0.15))
                            .cornerRadius(5)
                    }
                    .buttonStyle(.plain)
                    .disabled(!engine.isRunning)
                    .help("Interrupt Execution (Ctrl+C)")
                    
                    // Restart Shell Button (Ctrl+F6)
                    Button(action: { engine.restartShell() }) {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.blue)
                            .padding(5)
                            .background(Color.secondary.opacity(0.15))
                            .cornerRadius(5)
                    }
                    .buttonStyle(.plain)
                    .help("Restart Shell (Ctrl+F6)")
                    
                    // Clear Shell Button (Cmd+K)
                    Button(action: { engine.clearShell() }) {
                        Image(systemName: "trash")
                            .font(.system(size: 12))
                            .padding(5)
                            .background(Color.secondary.opacity(0.15))
                            .cornerRadius(5)
                    }
                    .buttonStyle(.plain)
                    .help("Clear Shell")
                }
                .fixedSize()
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(theme.gutterBackgroundColor)
            .overlay(
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(theme.separatorColor),
                alignment: .bottom
            )
            
            // Shell Output Area
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 2) {
                        ForEach(engine.shellEntries) { entry in
                            ShellEntryRowView(entry: entry, theme: theme, fontSize: fontSize, fontName: fontName)
                                .id(entry.id)
                        }
                    }
                    .padding(12)
                }
                .background(theme.backgroundColor)
                .onChange(of: engine.shellEntries.count) { _, _ in
                    if let last = engine.shellEntries.last {
                        withAnimation(.easeOut(duration: 0.15)) {
                            proxy.scrollTo(last.id, anchor: .bottom)
                        }
                    }
                }
            }
            
            // Bottom Interactive Input Row (IDLE REPL prompt)
            VStack(spacing: 0) {
                Rectangle()
                    .frame(height: 1)
                    .foregroundColor(theme.separatorColor)
                
                HStack(spacing: 8) {
                    Text(engine.isWaitingForInput ? "input: " : ">>> ")
                        .font(.system(size: fontSize, weight: .bold, design: .monospaced))
                        .foregroundColor(theme.shellPromptColor)
                    
                    TextField(
                        engine.isWaitingForInput ? "Enter input response..." : "Type Python statement or expression...",
                        text: $currentInputText
                    )
                    .textFieldStyle(.plain)
                    .font(.system(size: fontSize, design: .monospaced))
                    .foregroundColor(theme.textColor)
                    .disableTextCapitalization()
                    .autocorrectionDisabled(true)
                    .focused($isInputFocused)
                    .onSubmit {
                        submitCurrentInput()
                    }
                    
                    // History Up/Down quick buttons
                    HStack(spacing: 2) {
                        Button(action: navigateHistoryUp) {
                            Image(systemName: "chevron.up")
                                .font(.system(size: 11, weight: .bold))
                                .padding(6)
                                .background(Color.secondary.opacity(0.15))
                                .cornerRadius(4)
                        }
                        .buttonStyle(.plain)
                        
                        Button(action: navigateHistoryDown) {
                            Image(systemName: "chevron.down")
                                .font(.system(size: 11, weight: .bold))
                                .padding(6)
                                .background(Color.secondary.opacity(0.15))
                                .cornerRadius(4)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    // Return / Submit Button
                    Button(action: submitCurrentInput) {
                        Image(systemName: "arrow.turn.down.left")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.blue)
                            .cornerRadius(6)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(theme.gutterBackgroundColor)
            }
        }
        .onChange(of: engine.isWaitingForInput) { _, isWaiting in
            if isWaiting {
                isInputFocused = true
            }
        }
        .sheet(isPresented: $showHistorySheet) {
            ShellHistoryView(history: engine.commandHistory) { selected in
                currentInputText = selected
                isInputFocused = true
            }
        }
    }
    
    private func submitCurrentInput() {
        let text = currentInputText
        currentInputText = ""
        
        if engine.isWaitingForInput {
            engine.submitInput(text)
        } else {
            engine.executeREPLCommand(text)
        }
    }
    
    private func navigateHistoryUp() {
        if let prev = engine.previousHistoryCommand() {
            currentInputText = prev
        }
    }
    
    private func navigateHistoryDown() {
        if let next = engine.nextHistoryCommand() {
            currentInputText = next
        }
    }
}

// MARK: - Shell Entry Row View
struct ShellEntryRowView: View {
    let entry: ShellEntry
    let theme: EditorTheme
    let fontSize: CGFloat
    let fontName: String
    
    var body: some View {
        switch entry.kind {
        case .system:
            HStack {
                Spacer()
                Text(entry.text)
                    .font(.system(size: fontSize - 1, weight: .medium, design: .monospaced))
                    .foregroundColor(theme.shellSystemColor)
                    .multilineTextAlignment(.center)
                    .padding(.vertical, 4)
                Spacer()
            }
            
        case .prompt:
            Text(entry.text)
                .font(.system(size: fontSize, weight: .bold, design: .monospaced))
                .foregroundColor(theme.shellPromptColor)
            
        case .continuation:
            Text(entry.text)
                .font(.system(size: fontSize, weight: .semibold, design: .monospaced))
                .foregroundColor(theme.shellPromptColor.opacity(0.8))
            
        case .stdout:
            Text(entry.text)
                .font(.system(size: fontSize, design: .monospaced))
                .foregroundColor(theme.shellStdoutColor)
            
        case .stderr:
            Text(entry.text)
                .font(.system(size: fontSize, design: .monospaced))
                .foregroundColor(theme.shellStderrColor)
            
        case .result:
            Text(entry.text)
                .font(.system(size: fontSize, weight: .medium, design: .monospaced))
                .foregroundColor(theme.shellResultColor)
            
        case .inputPrompt:
            Text(entry.text)
                .font(.system(size: fontSize, weight: .medium, design: .monospaced))
                .foregroundColor(theme.shellPromptColor)
            
        case .userTyped:
            Text(entry.text)
                .font(.system(size: fontSize, design: .monospaced))
                .foregroundColor(theme.textColor)
        }
    }
}
