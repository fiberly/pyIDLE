import SwiftUI

public struct InputPromptSheet: View {
    public let prompt: String
    @Binding public var responseText: String
    public var onSubmit: (String) -> Void
    public var onCancel: () -> Void
    
    @FocusState private var isFocused: Bool
    
    public init(
        prompt: String,
        responseText: Binding<String>,
        onSubmit: @escaping (String) -> Void,
        onCancel: @escaping () -> Void
    ) {
        self.prompt = prompt
        self._responseText = responseText
        self.onSubmit = onSubmit
        self.onCancel = onCancel
    }
    
    public var body: some View {
        VStack(spacing: 16) {
            HStack {
                Image(systemName: "terminal.fill")
                    .foregroundColor(.blue)
                Text("Python input() Request")
                    .font(.headline)
                Spacer()
                Button("Cancel", action: onCancel)
                    .foregroundColor(.secondary)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text(prompt.isEmpty ? "Program requested input:" : prompt)
                    .font(.system(size: 15, weight: .medium, design: .monospaced))
                    .foregroundColor(.primary)
                    .lineLimit(3)
                
                TextField("Type response here...", text: $responseText)
                    .textFieldStyle(.roundedBorder)
                    .font(.system(size: 16, design: .monospaced))
                    .disableTextCapitalization()
                    .autocorrectionDisabled(true)
                    .focused($isFocused)
                    .onSubmit {
                        onSubmit(responseText)
                    }
            }
            
            HStack {
                Spacer()
                Button(action: {
                    onSubmit(responseText)
                }) {
                    HStack {
                        Image(systemName: "return")
                        Text("Submit")
                            .fontWeight(.semibold)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 8)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
            }
        }
        .padding(20)
        .background(.background)
        .cornerRadius(14)
        .shadow(radius: 10)
        .padding(24)
        .onAppear {
            isFocused = true
        }
    }
}
