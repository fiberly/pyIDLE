import SwiftUI

public struct ExamplesBrowserView: View {
    public var theme: EditorTheme
    public var onSelectExample: (ExampleScript) -> Void
    
    @State private var searchText = ""
    
    public init(theme: EditorTheme, onSelectExample: @escaping (ExampleScript) -> Void) {
        self.theme = theme
        self.onSelectExample = onSelectExample
    }
    
    private var filteredExamples: [ExampleScript] {
        if searchText.isEmpty {
            return ExampleScripts.all
        }
        return ExampleScripts.all.filter {
            $0.title.localizedCaseInsensitiveContains(searchText) ||
            $0.category.localizedCaseInsensitiveContains(searchText) ||
            $0.description.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    public var body: some View {
        List {
            ForEach(filteredExamples) { example in
                Button(action: {
                    onSelectExample(example)
                }) {
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: example.iconName)
                            .font(.system(size: 20))
                            .foregroundColor(.blue)
                            .frame(width: 28)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(example.title)
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(theme.textColor)
                                Spacer()
                                Text(example.category)
                                    .font(.caption2)
                                    .fontWeight(.medium)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.blue.opacity(0.18))
                                    .foregroundColor(.blue)
                                    .cornerRadius(4)
                            }
                            
                            Text(example.description)
                                .font(.caption)
                                .foregroundColor(theme.textColor.opacity(0.65))
                                .lineLimit(2)
                        }
                    }
                    .padding(.vertical, 4)
                }
                .listRowBackground(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(theme.isDark ? Color.white.opacity(0.04) : Color.black.opacity(0.02))
                )
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
    }
}
