import SwiftUI
import UniformTypeIdentifiers

public struct FileBrowserView: View {
    @Binding public var files: [PythonFile]
    @Binding public var activeFileId: UUID
    public var theme: EditorTheme
    public var onNewFile: () -> Void
    public var onOpenFileFromDisk: (URL) -> Void
    public var onSaveFileToDisk: (PythonFile) -> Void
    
    @State private var showDocumentPicker = false
    @State private var fileToRename: PythonFile?
    @State private var newFileName: String = ""
    @State private var showRenameAlert = false
    
    public init(
        files: Binding<[PythonFile]>,
        activeFileId: Binding<UUID>,
        theme: EditorTheme,
        onNewFile: @escaping () -> Void,
        onOpenFileFromDisk: @escaping (URL) -> Void,
        onSaveFileToDisk: @escaping (PythonFile) -> Void
    ) {
        self._files = files
        self._activeFileId = activeFileId
        self.theme = theme
        self.onNewFile = onNewFile
        self.onOpenFileFromDisk = onOpenFileFromDisk
        self.onSaveFileToDisk = onSaveFileToDisk
    }
    
    public var body: some View {
        List {
            Section(header: Text("Open Scripts").foregroundColor(theme.textColor.opacity(0.7))) {
                ForEach(files) { file in
                    HStack(spacing: 12) {
                        Image(systemName: "doc.text.fill")
                            .font(.system(size: 16))
                            .foregroundColor(file.id == activeFileId ? Color.blue : theme.textColor.opacity(0.6))
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text(file.titleWithStatus)
                                .font(.system(size: 14, weight: file.id == activeFileId ? .semibold : .regular, design: .monospaced))
                                .foregroundColor(theme.textColor)
                            
                            if let url = file.fileURL {
                                Text(url.path)
                                    .font(.system(size: 10))
                                    .foregroundColor(theme.textColor.opacity(0.5))
                                    .lineLimit(1)
                            }
                        }
                        
                        Spacer()
                        
                        if file.id == activeFileId {
                            Circle()
                                .fill(Color.blue)
                                .frame(width: 7, height: 7)
                        }
                    }
                    .padding(.vertical, 4)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        activeFileId = file.id
                    }
                    .listRowBackground(
                        file.id == activeFileId
                            ? RoundedRectangle(cornerRadius: 8)
                                .fill(Color.blue.opacity(theme.isDark ? 0.25 : 0.15))
                            : RoundedRectangle(cornerRadius: 8)
                                .fill(Color.clear)
                    )
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        if files.count > 1 {
                            Button(role: .destructive) {
                                if let idx = files.firstIndex(where: { $0.id == file.id }) {
                                    files.remove(at: idx)
                                    if activeFileId == file.id {
                                        activeFileId = files[0].id
                                    }
                                }
                            } label: {
                                Label("Close", systemImage: "xmark")
                            }
                        }
                        
                        Button {
                            onSaveFileToDisk(file)
                        } label: {
                            Label {
                                Text("Save to Files")
                            } icon: {
                                FloppyDiskIcon(size: 14)
                            }
                        }
                        .tint(.blue)
                        
                        Button {
                            fileToRename = file
                            newFileName = file.name
                            showRenameAlert = true
                        } label: {
                            Label("Rename", systemImage: "pencil")
                        }
                        .tint(.orange)
                    }
                }
            }
            
            Section(header: Text("Actions").foregroundColor(theme.textColor.opacity(0.7))) {
                Button(action: onNewFile) {
                    Label("New Python Script", systemImage: "plus.square.fill")
                        .foregroundColor(Color.blue)
                }
                
                Button(action: { showDocumentPicker = true }) {
                    Label("Open from Files...", systemImage: "folder.fill")
                        .foregroundColor(theme.textColor)
                }
                
                Button(action: {
                    if let active = files.first(where: { $0.id == activeFileId }) {
                        onSaveFileToDisk(active)
                    }
                }) {
                    HStack(spacing: 8) {
                        FloppyDiskIcon(size: 15)
                            .foregroundColor(theme.textColor)
                        Text("Save to Files...")
                            .foregroundColor(theme.textColor)
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
        .alert("Rename File", isPresented: $showRenameAlert) {
            TextField("File name", text: $newFileName)
            Button("Save") {
                if let target = fileToRename, let idx = files.firstIndex(where: { $0.id == target.id }) {
                    files[idx].name = newFileName.hasSuffix(".py") ? newFileName : "\(newFileName).py"
                }
            }
            Button("Cancel", role: .cancel) {}
        }
        .fileImporter(
            isPresented: $showDocumentPicker,
            allowedContentTypes: [.pythonScript, .plainText],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first {
                    onOpenFileFromDisk(url)
                }
            case .failure(let error):
                print("Failed to select file:", error)
            }
        }
    }
}
