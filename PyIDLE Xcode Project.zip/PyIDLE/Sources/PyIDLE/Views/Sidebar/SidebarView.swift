import SwiftUI

public enum SidebarTab: String, CaseIterable, Identifiable {
    case files = "Scripts"
    case examples = "Examples"
    case cheatSheet = "Cheat Sheet"
    case settings = "Settings"
    
    public var id: String { rawValue }
    
    public var icon: String {
        switch self {
        case .files: return "folder.fill"
        case .examples: return "sparkles.rectangle.stack.fill"
        case .cheatSheet: return "book.fill"
        case .settings: return "gearshape.fill"
        }
    }
}

public struct SidebarView: View {
    @Binding public var selectedTab: SidebarTab
    @Binding public var files: [PythonFile]
    @Binding public var activeFileId: UUID
    @Binding public var selectedTheme: ThemeType
    @Binding public var fontSize: CGFloat
    @Binding public var fontName: String
    @Binding public var autoPairBrackets: Bool
    @Binding public var showRestartBanner: Bool
    public var engineVersion: String
    public var theme: EditorTheme
    
    public var onNewFile: () -> Void
    public var onOpenFileFromDisk: (URL) -> Void
    public var onSaveFileToDisk: (PythonFile) -> Void
    public var onSelectExample: (ExampleScript) -> Void
    public var onInsertSnippet: (String) -> Void
    
    public init(
        selectedTab: Binding<SidebarTab>,
        files: Binding<[PythonFile]>,
        activeFileId: Binding<UUID>,
        selectedTheme: Binding<ThemeType>,
        fontSize: Binding<CGFloat>,
        fontName: Binding<String>,
        autoPairBrackets: Binding<Bool>,
        showRestartBanner: Binding<Bool>,
        engineVersion: String,
        theme: EditorTheme,
        onNewFile: @escaping () -> Void,
        onOpenFileFromDisk: @escaping (URL) -> Void,
        onSaveFileToDisk: @escaping (PythonFile) -> Void,
        onSelectExample: @escaping (ExampleScript) -> Void,
        onInsertSnippet: @escaping (String) -> Void
    ) {
        self._selectedTab = selectedTab
        self._files = files
        self._activeFileId = activeFileId
        self._selectedTheme = selectedTheme
        self._fontSize = fontSize
        self._fontName = fontName
        self._autoPairBrackets = autoPairBrackets
        self._showRestartBanner = showRestartBanner
        self.engineVersion = engineVersion
        self.theme = theme
        self.onNewFile = onNewFile
        self.onOpenFileFromDisk = onOpenFileFromDisk
        self.onSaveFileToDisk = onSaveFileToDisk
        self.onSelectExample = onSelectExample
        self.onInsertSnippet = onInsertSnippet
    }
    
    public var body: some View {
        VStack(spacing: 0) {
            // Translucent Liquid Glass Tab Picker Header
            VStack(spacing: 6) {
                Picker("Sidebar Section", selection: $selectedTab) {
                    ForEach(SidebarTab.allCases) { tab in
                        Label(tab.rawValue, systemImage: tab.icon).tag(tab)
                    }
                }
                .pickerStyle(.segmented)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .overlay(theme.separatorColor.opacity(0.3).frame(height: 0.5), alignment: .bottom)
            )
            
            // Content Views with translucent liquid glass list styling
            ZStack {
                switch selectedTab {
                case .files:
                    FileBrowserView(
                        files: $files,
                        activeFileId: $activeFileId,
                        theme: theme,
                        onNewFile: onNewFile,
                        onOpenFileFromDisk: onOpenFileFromDisk,
                        onSaveFileToDisk: onSaveFileToDisk
                    )
                    
                case .examples:
                    ExamplesBrowserView(
                        theme: theme,
                        onSelectExample: onSelectExample
                    )
                    
                case .cheatSheet:
                    PythonCheatSheetView(
                        theme: theme,
                        onInsertSnippet: onInsertSnippet
                    )
                    
                case .settings:
                    SettingsView(
                        selectedTheme: $selectedTheme,
                        fontSize: $fontSize,
                        fontName: $fontName,
                        autoPairBrackets: $autoPairBrackets,
                        showRestartBanner: $showRestartBanner,
                        engineVersion: engineVersion,
                        theme: theme
                    )
                }
            }
        }
        .background(
            ZStack {
                theme.backgroundColor.opacity(theme.isDark ? 0.88 : 0.65)
                Rectangle().fill(.ultraThinMaterial)
            }
            .ignoresSafeArea()
        )
        .navigationTitle("PyIDLE")
    }
}
