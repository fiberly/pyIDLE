import SwiftUI

public struct CheatSheetSection: Identifiable {
    public let id = UUID()
    public let title: String
    public let icon: String
    public let items: [(String, String)]
}

public struct PythonCheatSheetView: View {
    public var theme: EditorTheme
    public var onInsertSnippet: ((String) -> Void)?
    
    private let sections: [CheatSheetSection] = [
        CheatSheetSection(
            title: "Control Flow",
            icon: "arrow.triangle.branch",
            items: [
                ("if / elif / else", "if x > 0:\n    print('Positive')\nelif x == 0:\n    print('Zero')\nelse:\n    print('Negative')"),
                ("for loop with range", "for i in range(5):\n    print(i)"),
                ("for loop with enumerate", "for idx, val in enumerate(items):\n    print(f\"{idx}: {val}\")"),
                ("while loop", "while count > 0:\n    count -= 1")
            ]
        ),
        CheatSheetSection(
            title: "Functions & Lambdas",
            icon: "function",
            items: [
                ("Function Definition", "def calculate(a: int, b: int = 10) -> int:\n    return a + b"),
                ("Lambda Expression", "square = lambda x: x ** 2"),
                ("Arbitrary Arguments (*args, **kwargs)", "def log_all(*args, **kwargs):\n    print(args, kwargs)")
            ]
        ),
        CheatSheetSection(
            title: "Data Structures & Comprehensions",
            icon: "square.stack.3d.down.right.fill",
            items: [
                ("List Comprehension", "squares = [x**2 for x in range(10) if x % 2 == 0]"),
                ("Dictionary Comprehension", "word_lengths = {w: len(w) for w in ['apple', 'banana', 'cherry']}"),
                ("Set Comprehension", "unique_chars = {char.lower() for char in 'Hello World'}"),
                ("Dictionary Operations", "d = {'a': 1, 'b': 2}\nval = d.get('c', 0)")
            ]
        ),
        CheatSheetSection(
            title: "Turtle Graphics",
            icon: "paintpalette.fill",
            items: [
                ("Basic Movement", "import turtle\nt = turtle.Turtle()\nt.forward(100)\nt.right(90)\nt.backward(50)"),
                ("Colors & Pen", "t.color('#FF5733')\nt.pensize(3)\nt.penup()\nt.goto(50, 50)\nt.pendown()"),
                ("Circles & Fills", "t.begin_fill()\nt.circle(50)\nt.end_fill()")
            ]
        ),
        CheatSheetSection(
            title: "String Formatting (f-strings)",
            icon: "text.quote",
            items: [
                ("Variable Interpolation", "name = 'Ada'\nprint(f'Hello, {name}!')"),
                ("Floating Point Precision", "val = 3.1415926\nprint(f'{val:.2f}')  # 3.14"),
                ("Expressions Inside f-strings", "print(f'2 + 2 = {2 + 2}')")
            ]
        ),
        CheatSheetSection(
            title: "Exception Handling",
            icon: "exclamationmark.triangle.fill",
            items: [
                ("try / except / finally", "try:\n    res = 10 / 0\nexcept ZeroDivisionError as e:\n    print(f'Error: {e}')\nfinally:\n    print('Cleanup')")
            ]
        )
    ]
    
    public init(theme: EditorTheme, onInsertSnippet: ((String) -> Void)? = nil) {
        self.theme = theme
        self.onInsertSnippet = onInsertSnippet
    }
    
    public var body: some View {
        List {
            ForEach(sections) { sec in
                Section(header: Label(sec.title, systemImage: sec.icon).foregroundColor(theme.textColor.opacity(0.8))) {
                    ForEach(sec.items, id: \.0) { title, snippet in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(title)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(theme.textColor)
                                Spacer()
                                if let onInsert = onInsertSnippet {
                                    Button("Insert") {
                                        onInsert(snippet)
                                    }
                                    .font(.caption2)
                                    .buttonStyle(.bordered)
                                }
                            }
                            
                            Text(snippet)
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundColor(theme.textColor.opacity(0.9))
                                .padding(8)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(theme.isDark ? Color.white.opacity(0.06) : Color.black.opacity(0.04))
                                .cornerRadius(6)
                        }
                        .padding(.vertical, 4)
                    }
                }
                .listRowBackground(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(theme.isDark ? Color.white.opacity(0.02) : Color.black.opacity(0.02))
                )
            }
        }
        .listStyle(.sidebar)
        .scrollContentBackground(.hidden)
    }
}
