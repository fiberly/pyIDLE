import SwiftUI

public struct SettingsView: View {
    @Binding public var selectedTheme: ThemeType
    @Binding public var fontSize: CGFloat
    @Binding public var fontName: String
    @Binding public var autoPairBrackets: Bool
    @Binding public var showRestartBanner: Bool
    public var engineVersion: String
    public var theme: EditorTheme
    
    private let availableFonts = ["SF Mono", "Menlo", "Courier", "Courier New"]
    
    public init(
        selectedTheme: Binding<ThemeType>,
        fontSize: Binding<CGFloat>,
        fontName: Binding<String>,
        autoPairBrackets: Binding<Bool>,
        showRestartBanner: Binding<Bool>,
        engineVersion: String,
        theme: EditorTheme
    ) {
        self._selectedTheme = selectedTheme
        self._fontSize = fontSize
        self._fontName = fontName
        self._autoPairBrackets = autoPairBrackets
        self._showRestartBanner = showRestartBanner
        self.engineVersion = engineVersion
        self.theme = theme
    }
    
    public var body: some View {
        Form {
            Section(header: Text("Appearance & Theme").foregroundColor(theme.textColor.opacity(0.8))) {
                Picker("Color Theme", selection: $selectedTheme) {
                    ForEach(ThemeType.allCases) { theme in
                        Text(theme.rawValue).tag(theme)
                    }
                }
                
                Picker("Font Family", selection: $fontName) {
                    ForEach(availableFonts, id: \.self) { font in
                        Text(font).tag(font)
                    }
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Font Size")
                        Spacer()
                        Text("\(Int(fontSize)) pt")
                            .foregroundColor(.secondary)
                            .font(.system(.body, design: .monospaced))
                    }
                    Slider(value: $fontSize, in: 12...24, step: 1)
                }
            }
            
            Section(header: Text("Editor & Shell Behavior").foregroundColor(theme.textColor.opacity(0.8))) {
                Toggle("Auto-Pair Brackets and Quotes", isOn: $autoPairBrackets)
                Toggle("Show 'RESTART: filename.py' on Run", isOn: $showRestartBanner)
                HStack {
                    Text("Tab Size")
                    Spacer()
                    Text("4 spaces")
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Auto-Indentation")
                    Spacer()
                    Text("Enabled (after :)")
                        .foregroundColor(.secondary)
                }
            }
            
            Section(header: Text("Python Engine").foregroundColor(theme.textColor.opacity(0.8))) {
                HStack {
                    Text("CPython Runtime")
                    Spacer()
                    Text(engineVersion)
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Architecture")
                    Spacer()
                    Text("WebAssembly (WASM) / Pyodide")
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Platform")
                    Spacer()
                    Text("iPadOS Native SwiftUI")
                        .foregroundColor(.secondary)
                }
            }
            
            Section(header: Text("About PyIDLE").foregroundColor(theme.textColor.opacity(0.8))) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("PyIDLE for iPad")
                        .font(.headline)
                        .foregroundColor(theme.textColor)
                    Text("A modern, full-featured Python Integrated Development and Learning Environment for iPad.")
                        .font(.caption)
                        .foregroundColor(theme.textColor.opacity(0.65))
                }
                .padding(.vertical, 4)
            }
        }
        .scrollContentBackground(.hidden)
    }
}
