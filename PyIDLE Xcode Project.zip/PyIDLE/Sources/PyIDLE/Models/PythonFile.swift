import Foundation
import SwiftUI
import UniformTypeIdentifiers

public struct PythonFile: Identifiable, Hashable, Codable {
    public var id: UUID
    public var name: String
    public var content: String
    public var fileURL: URL?
    public var isModified: Bool
    public var lastSavedContent: String
    public var dateCreated: Date
    public var dateModified: Date
    
    public init(
        id: UUID = UUID(),
        name: String = "untitled.py",
        content: String = "",
        fileURL: URL? = nil,
        isModified: Bool = false
    ) {
        self.id = id
        self.name = name
        self.content = content
        self.lastSavedContent = content
        self.fileURL = fileURL
        self.isModified = isModified
        self.dateCreated = Date()
        self.dateModified = Date()
    }
    
    public var displayName: String {
        return name.hasSuffix(".py") ? name : "\(name).py"
    }
    
    public var titleWithStatus: String {
        return isModified ? "*\(displayName)" : displayName
    }
    
    public mutating func updateContent(_ newContent: String) {
        if content != newContent {
            content = newContent
            isModified = (content != lastSavedContent)
            dateModified = Date()
        }
    }
    
    public mutating func markSaved(at url: URL? = nil) {
        if let url = url {
            self.fileURL = url
            self.name = url.lastPathComponent
        }
        self.lastSavedContent = content
        self.isModified = false
        self.dateModified = Date()
    }
    
    public static func defaultFile() -> PythonFile {
        let sample = """
        # PyIDLE — Python on iPadOS
        # Press the Run button (or Cmd+R) to execute!

        def greet(name: str) -> str:
            return f"Hello, {name}! Welcome to PyIDLE on iPad."

        print(greet("Pythonista"))

        # Try a list comprehension
        squares = [x**2 for x in range(1, 11)]
        print(f"Squares from 1 to 10: {squares}")
        """
        return PythonFile(name: "main.py", content: sample, isModified: false)
    }
}

public struct PythonDocument: FileDocument {
    public static var readableContentTypes: [UTType] {
        if let pyType = UTType("public.python-script") {
            return [pyType, .plainText]
        }
        return [.plainText]
    }
    
    public static var writableContentTypes: [UTType] {
        if let pyType = UTType("public.python-script") {
            return [pyType, .plainText]
        }
        return [.plainText]
    }
    
    public var text: String
    
    public init(text: String = "") {
        self.text = text
    }
    
    public init(configuration: ReadConfiguration) throws {
        if let data = configuration.file.regularFileContents,
           let str = String(data: data, encoding: .utf8) {
            self.text = str
        } else {
            self.text = ""
        }
    }
    
    public func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        let data = Data(text.utf8)
        return FileWrapper(regularFileWithContents: data)
    }
}
