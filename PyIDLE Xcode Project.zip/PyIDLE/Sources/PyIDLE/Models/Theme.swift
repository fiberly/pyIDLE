import SwiftUI

#if canImport(UIKit)
import UIKit
#endif

public enum ThemeType: String, CaseIterable, Identifiable, Codable {
    case idleClassic = "IDLE Classic"
    case idleDark = "IDLE Dark"
    case monokai = "Monokai"
    case solarizedLight = "Solarized Light"
    case solarizedDark = "Solarized Dark"
    
    public var id: String { rawValue }
    
    public var theme: EditorTheme {
        switch self {
        case .idleClassic:
            return EditorTheme.idleClassic
        case .idleDark:
            return EditorTheme.idleDark
        case .monokai:
            return EditorTheme.monokai
        case .solarizedLight:
            return EditorTheme.solarizedLight
        case .solarizedDark:
            return EditorTheme.solarizedDark
        }
    }
}

public struct EditorTheme: Equatable {
    public let name: String
    public let isDark: Bool
    
    // Backgrounds & Chrome
    public let backgroundColor: Color
    public let gutterBackgroundColor: Color
    public let currentLineColor: Color
    public let selectionColor: Color
    public let separatorColor: Color
    
    // Text & Syntax
    public let textColor: Color
    public let gutterTextColor: Color
    public let keywordColor: Color
    public let builtinColor: Color
    public let stringColor: Color
    public let commentColor: Color
    public let numberColor: Color
    public let definitionColor: Color
    public let decoratorColor: Color
    public let operatorColor: Color
    
    // Shell Colors
    public let shellPromptColor: Color
    public let shellStdoutColor: Color
    public let shellStderrColor: Color
    public let shellSystemColor: Color
    public let shellResultColor: Color
    
    #if canImport(UIKit)
    public var uiBackgroundColor: UIColor { UIColor(backgroundColor) }
    public var uiTextColor: UIColor { UIColor(textColor) }
    public var uiGutterBackgroundColor: UIColor { UIColor(gutterBackgroundColor) }
    public var uiGutterTextColor: UIColor { UIColor(gutterTextColor) }
    public var uiKeywordColor: UIColor { UIColor(keywordColor) }
    public var uiBuiltinColor: UIColor { UIColor(builtinColor) }
    public var uiStringColor: UIColor { UIColor(stringColor) }
    public var uiCommentColor: UIColor { UIColor(commentColor) }
    public var uiNumberColor: UIColor { UIColor(numberColor) }
    public var uiDefinitionColor: UIColor { UIColor(definitionColor) }
    public var uiDecoratorColor: UIColor { UIColor(decoratorColor) }
    public var uiOperatorColor: UIColor { UIColor(operatorColor) }
    public var uiCurrentLineColor: UIColor { UIColor(currentLineColor) }
    public var uiSelectionColor: UIColor { UIColor(selectionColor) }
    #endif
    
    // MARK: - Presets
    
    public static let idleClassic = EditorTheme(
        name: "IDLE Classic",
        isDark: false,
        backgroundColor: Color(hex: "FFFFFF"),
        gutterBackgroundColor: Color(hex: "F7F7F7"),
        currentLineColor: Color(hex: "E8EEF7"),
        selectionColor: Color(hex: "BBD7FB"),
        separatorColor: Color(hex: "DDDDDD"),
        textColor: Color(hex: "000000"),
        gutterTextColor: Color(hex: "888888"),
        keywordColor: Color(hex: "FF7700"),     // IDLE Classic Orange
        builtinColor: Color(hex: "900090"),     // IDLE Classic Purple
        stringColor: Color(hex: "00AA00"),      // IDLE Classic Green
        commentColor: Color(hex: "DD0000"),     // IDLE Classic Red
        numberColor: Color(hex: "0000CD"),      // Medium Blue
        definitionColor: Color(hex: "0000FF"),  // Pure Blue for def/class names
        decoratorColor: Color(hex: "AA00AA"),   // Magenta
        operatorColor: Color(hex: "333333"),
        shellPromptColor: Color(hex: "770000"),  // IDLE prompt dark red
        shellStdoutColor: Color(hex: "0000FF"),  // IDLE standard stdout blue
        shellStderrColor: Color(hex: "DD0000"),  // IDLE standard stderr red
        shellSystemColor: Color(hex: "777777"),  // IDLE restart banner gray
        shellResultColor: Color(hex: "0000AA")
    )
    
    public static let idleDark = EditorTheme(
        name: "IDLE Dark",
        isDark: true,
        backgroundColor: Color(hex: "1E1E24"),
        gutterBackgroundColor: Color(hex: "18181D"),
        currentLineColor: Color(hex: "292934"),
        selectionColor: Color(hex: "3A4D6B"),
        separatorColor: Color(hex: "2E2E38"),
        textColor: Color(hex: "E0E0E6"),
        gutterTextColor: Color(hex: "6A6A78"),
        keywordColor: Color(hex: "FF9E3B"),     // Bright Warm Orange
        builtinColor: Color(hex: "C678DD"),     // Vibrant Purple
        stringColor: Color(hex: "98C379"),      // Soft Green
        commentColor: Color(hex: "E06C75"),     // Coral Red
        numberColor: Color(hex: "61AFEF"),      // Light Blue
        definitionColor: Color(hex: "56B6C2"),  // Cyan
        decoratorColor: Color(hex: "D19A66"),   // Gold
        operatorColor: Color(hex: "ABB2BF"),
        shellPromptColor: Color(hex: "E5C07B"),  // Gold prompt
        shellStdoutColor: Color(hex: "61AFEF"),  // Cyan/Blue stdout
        shellStderrColor: Color(hex: "FF6B6B"),  // Red stderr
        shellSystemColor: Color(hex: "7F848E"),  // Gray
        shellResultColor: Color(hex: "98C379")
    )
    
    public static let monokai = EditorTheme(
        name: "Monokai",
        isDark: true,
        backgroundColor: Color(hex: "272822"),
        gutterBackgroundColor: Color(hex: "1E1F1C"),
        currentLineColor: Color(hex: "3E3D32"),
        selectionColor: Color(hex: "49483E"),
        separatorColor: Color(hex: "3B3A32"),
        textColor: Color(hex: "F8F8F2"),
        gutterTextColor: Color(hex: "75715E"),
        keywordColor: Color(hex: "F92672"),     // Pink
        builtinColor: Color(hex: "66D9EF"),     // Cyan
        stringColor: Color(hex: "E6DB74"),      // Yellow
        commentColor: Color(hex: "75715E"),     // Muted olive
        numberColor: Color(hex: "AE81FF"),      // Purple
        definitionColor: Color(hex: "A6E22E"),  // Green
        decoratorColor: Color(hex: "FD971F"),   // Orange
        operatorColor: Color(hex: "F8F8F2"),
        shellPromptColor: Color(hex: "A6E22E"),
        shellStdoutColor: Color(hex: "F8F8F2"),
        shellStderrColor: Color(hex: "F92672"),
        shellSystemColor: Color(hex: "75715E"),
        shellResultColor: Color(hex: "66D9EF")
    )
    
    public static let solarizedLight = EditorTheme(
        name: "Solarized Light",
        isDark: false,
        backgroundColor: Color(hex: "FDF6E3"),
        gutterBackgroundColor: Color(hex: "EEE8D5"),
        currentLineColor: Color(hex: "EDE6D1"),
        selectionColor: Color(hex: "DFD6C2"),
        separatorColor: Color(hex: "D8D1BD"),
        textColor: Color(hex: "657B83"),
        gutterTextColor: Color(hex: "93A1A1"),
        keywordColor: Color(hex: "859900"),     // Green
        builtinColor: Color(hex: "B58900"),     // Yellow
        stringColor: Color(hex: "2AA198"),      // Cyan
        commentColor: Color(hex: "93A1A1"),     // Base1
        numberColor: Color(hex: "D33682"),      // Magenta
        definitionColor: Color(hex: "268BD2"),  // Blue
        decoratorColor: Color(hex: "CB4B16"),   // Orange
        operatorColor: Color(hex: "586E75"),
        shellPromptColor: Color(hex: "CB4B16"),
        shellStdoutColor: Color(hex: "268BD2"),
        shellStderrColor: Color(hex: "DC322F"),
        shellSystemColor: Color(hex: "93A1A1"),
        shellResultColor: Color(hex: "859900")
    )
    
    public static let solarizedDark = EditorTheme(
        name: "Solarized Dark",
        isDark: true,
        backgroundColor: Color(hex: "002B36"),
        gutterBackgroundColor: Color(hex: "073642"),
        currentLineColor: Color(hex: "073642"),
        selectionColor: Color(hex: "0B4856"),
        separatorColor: Color(hex: "073642"),
        textColor: Color(hex: "839496"),
        gutterTextColor: Color(hex: "586E75"),
        keywordColor: Color(hex: "859900"),     // Green
        builtinColor: Color(hex: "B58900"),     // Yellow
        stringColor: Color(hex: "2AA198"),      // Cyan
        commentColor: Color(hex: "586E75"),     // Base01
        numberColor: Color(hex: "D33682"),      // Magenta
        definitionColor: Color(hex: "268BD2"),  // Blue
        decoratorColor: Color(hex: "CB4B16"),   // Orange
        operatorColor: Color(hex: "93A1A1"),
        shellPromptColor: Color(hex: "CB4B16"),
        shellStdoutColor: Color(hex: "268BD2"),
        shellStderrColor: Color(hex: "DC322F"),
        shellSystemColor: Color(hex: "586E75"),
        shellResultColor: Color(hex: "859900")
    )
}

// MARK: - Color Hex Initializer
extension Color {
    public init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
