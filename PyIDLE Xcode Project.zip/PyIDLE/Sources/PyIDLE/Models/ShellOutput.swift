import Foundation
import SwiftUI

public enum ShellEntryKind: String, Codable {
    case prompt       // ">>> "
    case continuation // "... "
    case stdout       // standard output text
    case stderr       // errors, tracebacks
    case system       // "=== RESTART: ... ==="
    case result       // interactive REPL return value
    case inputPrompt  // from Python's input(...)
    case userTyped    // what the user typed in response to input
}

public struct ShellEntry: Identifiable, Codable, Hashable {
    public let id: UUID
    public let kind: ShellEntryKind
    public let text: String
    public let timestamp: Date
    
    public init(id: UUID = UUID(), kind: ShellEntryKind, text: String, timestamp: Date = Date()) {
        self.id = id
        self.kind = kind
        self.text = text
        self.timestamp = timestamp
    }
}
