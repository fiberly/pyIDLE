import Foundation

public struct ExampleScript: Identifiable, Hashable {
    public let id = UUID()
    public let title: String
    public let category: String
    public let description: String
    public let iconName: String
    public let code: String
}

public enum ExampleScripts {
    public static let all: [ExampleScript] = [
        ExampleScript(
            title: "Hello & Interactive Input",
            category: "Basics",
            description: "Demonstrates interactive input(), string manipulation, and math calculations.",
            iconName: "person.wave.2.fill",
            code: """
            # Interactive Hello & Calculator
            # Press Run (Cmd+R or F5) to start!

            print("========================================")
            print("  Welcome to Python on iPad with PyIDLE ")
            print("========================================")

            name = input("Enter your name: ")
            print(f"\\nGreat to meet you, {name}!")

            try:
                age_str = input("What year were you born? ")
                birth_year = int(age_str)
                current_year = 2026
                age = current_year - birth_year
                print(f"You are approximately {age} years old in {current_year}.")
            except ValueError:
                print("That didn't look like a valid year number.")

            print("\\nDone! You can type expressions directly in the Shell below.")
            """
        ),
        
        ExampleScript(
            title: "Turtle Graphics Mandala",
            category: "Visual Graphics",
            description: "Draws an intricate colorful spiral mandala using the Python turtle module.",
            iconName: "paintpalette.fill",
            code: """
            # Turtle Graphics — Colorful Spiral Mandala
            # PyIDLE automatically renders Turtle drawings to the Canvas tab!

            import turtle

            t = turtle.Turtle()
            t.speed(0) # Fastest
            t.pensize(2)

            colors = ["#FF5733", "#33FF57", "#3357FF", "#F3FF33", "#FF33F3", "#33FFF0"]

            for i in range(120):
                t.color(colors[i % len(colors)])
                t.forward(i * 3)
                t.right(59)

            print("Mandala drawing complete! Check the Canvas tab to see your creation.")
            """
        ),
        
        ExampleScript(
            title: "Fibonacci & Performance",
            category: "Algorithms",
            description: "Compares recursive Fibonacci with memoization and iterative approaches.",
            iconName: "function",
            code: """
            # Fibonacci with Memoization & Timing
            import time
            from functools import lru_cache

            @lru_cache(maxsize=None)
            def fib_memo(n: int) -> int:
                if n <= 1:
                    return n
                return fib_memo(n - 1) + fib_memo(n - 2)

            def fib_iter(n: int) -> int:
                a, b = 0, 1
                for _ in range(n):
                    a, b = b, a + b
                return a

            print("Calculating Fibonacci sequence up to n=35...")

            start = time.time()
            res1 = fib_memo(35)
            t1 = time.time() - start
            print(f"Memoized fib(35) = {res1} (took {t1*1000:.4f} ms)")

            start = time.time()
            res2 = fib_iter(35)
            t2 = time.time() - start
            print(f"Iterative fib(35) = {res2} (took {t2*1000:.4f} ms)")

            print("\\nFirst 15 Fibonacci numbers:")
            print([fib_iter(i) for i in range(15)])
            """
        ),
        
        ExampleScript(
            title: "OOP Bank Account System",
            category: "Object-Oriented",
            description: "Classes, inheritance, properties, and custom exceptions in Python.",
            iconName: "building.columns.fill",
            code: """
            # Object-Oriented Programming: Bank Account System

            class InsufficientFundsError(Exception):
                pass

            class Account:
                def __init__(self, owner: str, balance: float = 0.0):
                    self.owner = owner
                    self._balance = balance
                    self.transactions = []
                
                @property
                def balance(self) -> float:
                    return self._balance
                
                def deposit(self, amount: float):
                    if amount <= 0:
                        raise ValueError("Deposit amount must be positive.")
                    self._balance += amount
                    self.transactions.append(f"+${amount:.2f} Deposit")
                    print(f"[{self.owner}] Deposited ${amount:.2f}. New Balance: ${self._balance:.2f}")

                def withdraw(self, amount: float):
                    if amount > self._balance:
                        raise InsufficientFundsError(f"Cannot withdraw ${amount:.2f}, only ${self._balance:.2f} available.")
                    self._balance -= amount
                    self.transactions.append(f"-${amount:.2f} Withdrawal")
                    print(f"[{self.owner}] Withdrew ${amount:.2f}. Remaining Balance: ${self._balance:.2f}")

                def statement(self):
                    print(f"\\n--- Statement for {self.owner} ---")
                    for tx in self.transactions:
                        print(f"  {tx}")
                    print(f"Total Balance: ${self._balance:.2f}\\n")

            # Create an account
            acc = Account("Ada Lovelace", 500.0)
            acc.deposit(250.0)
            acc.withdraw(120.0)
            acc.statement()
            """
        ),
        
        ExampleScript(
            title: "Text Adventure Game",
            category: "Games & Interactive",
            description: "Interactive dungeon crawler game with items, monsters, and decision making.",
            iconName: "gamecontroller.fill",
            code: """
            # Text Adventure Dungeon Crawler
            # An interactive game in PyIDLE

            def play_game():
                print("🏰 You awaken in the entrance of a mysterious ancient dungeon.")
                inventory = []
                hp = 100

                while hp > 0:
                    print("\\nChoose your action:")
                    print("1. Go left into the Armory")
                    print("2. Go right into the Library")
                    print("3. Venture forward to the Dragon Chamber")
                    print("4. Check Status")
                    print("5. Flee dungeon (Quit)")

                    choice = input("Enter choice (1-5): ").strip()

                    if choice == "1":
                        if "Silver Sword" not in inventory:
                            print("⚔️ You found a shiny Silver Sword on the weapon rack!")
                            inventory.append("Silver Sword")
                        else:
                            print("The armory is empty now.")
                    elif choice == "2":
                        if "Healing Potion" not in inventory:
                            print("🧪 You discovered a Healing Potion tucked in an ancient tome!")
                            inventory.append("Healing Potion")
                        else:
                            print("Dusty books fill the shelves.")
                    elif choice == "3":
                        print("🐉 A sleeping red dragon lies before a mountain of gold!")
                        if "Silver Sword" in inventory:
                            print("✨ You wield the Silver Sword and bravely defeat the dragon!")
                            print("🎉 YOU WIN! You are now the dungeon master!")
                            break
                        else:
                            print("🔥 Without a weapon, the dragon wakes and breathes fire!")
                            hp -= 50
                            print(f"You barely escape! HP remaining: {hp}")
                    elif choice == "4":
                        print(f"❤️ HP: {hp}/100 | 🎒 Inventory: {inventory or 'Empty'}")
                    elif choice == "5":
                        print("You fled the dungeon safely.")
                        break
                    else:
                        print("Invalid command. Try again.")

                print("\\nThanks for playing PyIDLE Adventure!")

            play_game()
            """
        ),
        
        ExampleScript(
            title: "Sieve of Eratosthenes",
            category: "Algorithms",
            description: "Fast prime number generator using array sieving.",
            iconName: "number.circle.fill",
            code: """
            # Sieve of Eratosthenes
            # Generates all prime numbers up to a given limit

            def sieve_primes(limit: int) -> list[int]:
                if limit < 2:
                    return []
                
                is_prime = [True] * (limit + 1)
                is_prime[0] = is_prime[1] = False

                for p in range(2, int(limit**0.5) + 1):
                    if is_prime[p]:
                        for multiple in range(p * p, limit + 1, p):
                            is_prime[multiple] = False

                return [num for num, prime in enumerate(is_prime) if prime]

            limit = 100
            primes = sieve_primes(limit)
            print(f"Found {len(primes)} primes up to {limit}:")
            print(primes)
            """
        )
    ]
}
